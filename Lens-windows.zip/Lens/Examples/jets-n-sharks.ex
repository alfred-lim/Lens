min:1 max:10 defI:-;
name:{Lance-in}
i:{Instance} 9;
name:{Art-in}
i:{Instance} 0;
name:{Rick-in}
i:{Instance} 23;
name:{Sam-in}
i:{Instance} 2;
name:{Ralph-in}
i:{Instance} 14;
name:{Ken-in}
i:{Instance} 21;
name:{Lance}
i:{Name} 9;
name:{Art}
i:{Name} 0;
name:{Rick}
i:{Name} 23;
name:{Sam}
i:{Name} 2;
name:{Ralph}
i:{Name} 14;
name:{Ken}
i:{Name} 21;
name:{Sharks 20's (Ken)}
i:{Gang} 1 {Age} 2;
name:{Div. Pusher (Dave)}
i:{Marital} 2 {Job} 0;
name:{Lance-in on/off} 2
[0 max:3]
i:{Instance} 9;
name:{Art-in on/off} 2
[0 max:3]
i:{Instance} 0;
name:{Rick-in on/off} 2
[0 max:3]
i:{Instance} 23;
