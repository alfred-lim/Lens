name:{T 0 0 up}
i: 0 1 2 10 19 T:1;
name:{T 0 0 right}
i: 2 9 10 11 20 T:1;
name:{T 0 0 down}
i: 1 10 18 19 20 T:1;
name:{T 0 0 left}
i: 0 9 10 11 18 T:1;
name:{C 0 0 up}
i: 1 2 10 19 20 T:0;
name:{C 0 0 right}
i: 9 10 11 18 20 T:0;
name:{C 0 0 down}
i: 0 1 10 18 19 T:0;
name:{C 0 0 left}
i: 0 2 9 10 11 T:0;
name:{T 0 1 up}
i: 1 2 3 11 20 T:1;
name:{T 0 1 right}
i: 3 10 11 12 21 T:1;
name:{T 0 1 down}
i: 2 11 19 20 21 T:1;
name:{T 0 1 left}
i: 1 10 11 12 19 T:1;
name:{C 0 1 up}
i: 2 3 11 20 21 T:0;
name:{C 0 1 right}
i: 10 11 12 19 21 T:0;
name:{C 0 1 down}
i: 1 2 11 19 20 T:0;
name:{C 0 1 left}
i: 1 3 10 11 12 T:0;
name:{T 0 2 up}
i: 2 3 4 12 21 T:1;
name:{T 0 2 right}
i: 4 11 12 13 22 T:1;
name:{T 0 2 down}
i: 3 12 20 21 22 T:1;
name:{T 0 2 left}
i: 2 11 12 13 20 T:1;
name:{C 0 2 up}
i: 3 4 12 21 22 T:0;
name:{C 0 2 right}
i: 11 12 13 20 22 T:0;
name:{C 0 2 down}
i: 2 3 12 20 21 T:0;
name:{C 0 2 left}
i: 2 4 11 12 13 T:0;
name:{T 0 3 up}
i: 3 4 5 13 22 T:1;
name:{T 0 3 right}
i: 5 12 13 14 23 T:1;
name:{T 0 3 down}
i: 4 13 21 22 23 T:1;
name:{T 0 3 left}
i: 3 12 13 14 21 T:1;
name:{C 0 3 up}
i: 4 5 13 22 23 T:0;
name:{C 0 3 right}
i: 12 13 14 21 23 T:0;
name:{C 0 3 down}
i: 3 4 13 21 22 T:0;
name:{C 0 3 left}
i: 3 5 12 13 14 T:0;
name:{T 0 4 up}
i: 4 5 6 14 23 T:1;
name:{T 0 4 right}
i: 6 13 14 15 24 T:1;
name:{T 0 4 down}
i: 5 14 22 23 24 T:1;
name:{T 0 4 left}
i: 4 13 14 15 22 T:1;
name:{C 0 4 up}
i: 5 6 14 23 24 T:0;
name:{C 0 4 right}
i: 13 14 15 22 24 T:0;
name:{C 0 4 down}
i: 4 5 14 22 23 T:0;
name:{C 0 4 left}
i: 4 6 13 14 15 T:0;
name:{T 0 5 up}
i: 5 6 7 15 24 T:1;
name:{T 0 5 right}
i: 7 14 15 16 25 T:1;
name:{T 0 5 down}
i: 6 15 23 24 25 T:1;
name:{T 0 5 left}
i: 5 14 15 16 23 T:1;
name:{C 0 5 up}
i: 6 7 15 24 25 T:0;
name:{C 0 5 right}
i: 14 15 16 23 25 T:0;
name:{C 0 5 down}
i: 5 6 15 23 24 T:0;
name:{C 0 5 left}
i: 5 7 14 15 16 T:0;
name:{T 0 6 up}
i: 6 7 8 16 25 T:1;
name:{T 0 6 right}
i: 8 15 16 17 26 T:1;
name:{T 0 6 down}
i: 7 16 24 25 26 T:1;
name:{T 0 6 left}
i: 6 15 16 17 24 T:1;
name:{C 0 6 up}
i: 7 8 16 25 26 T:0;
name:{C 0 6 right}
i: 15 16 17 24 26 T:0;
name:{C 0 6 down}
i: 6 7 16 24 25 T:0;
name:{C 0 6 left}
i: 6 8 15 16 17 T:0;
name:{T 1 0 up}
i: 9 10 11 19 28 T:1;
name:{T 1 0 right}
i: 11 18 19 20 29 T:1;
name:{T 1 0 down}
i: 10 19 27 28 29 T:1;
name:{T 1 0 left}
i: 9 18 19 20 27 T:1;
name:{C 1 0 up}
i: 10 11 19 28 29 T:0;
name:{C 1 0 right}
i: 18 19 20 27 29 T:0;
name:{C 1 0 down}
i: 9 10 19 27 28 T:0;
name:{C 1 0 left}
i: 9 11 18 19 20 T:0;
name:{T 1 1 up}
i: 10 11 12 20 29 T:1;
name:{T 1 1 right}
i: 12 19 20 21 30 T:1;
name:{T 1 1 down}
i: 11 20 28 29 30 T:1;
name:{T 1 1 left}
i: 10 19 20 21 28 T:1;
name:{C 1 1 up}
i: 11 12 20 29 30 T:0;
name:{C 1 1 right}
i: 19 20 21 28 30 T:0;
name:{C 1 1 down}
i: 10 11 20 28 29 T:0;
name:{C 1 1 left}
i: 10 12 19 20 21 T:0;
name:{T 1 2 up}
i: 11 12 13 21 30 T:1;
name:{T 1 2 right}
i: 13 20 21 22 31 T:1;
name:{T 1 2 down}
i: 12 21 29 30 31 T:1;
name:{T 1 2 left}
i: 11 20 21 22 29 T:1;
name:{C 1 2 up}
i: 12 13 21 30 31 T:0;
name:{C 1 2 right}
i: 20 21 22 29 31 T:0;
name:{C 1 2 down}
i: 11 12 21 29 30 T:0;
name:{C 1 2 left}
i: 11 13 20 21 22 T:0;
name:{T 1 3 up}
i: 12 13 14 22 31 T:1;
name:{T 1 3 right}
i: 14 21 22 23 32 T:1;
name:{T 1 3 down}
i: 13 22 30 31 32 T:1;
name:{T 1 3 left}
i: 12 21 22 23 30 T:1;
name:{C 1 3 up}
i: 13 14 22 31 32 T:0;
name:{C 1 3 right}
i: 21 22 23 30 32 T:0;
name:{C 1 3 down}
i: 12 13 22 30 31 T:0;
name:{C 1 3 left}
i: 12 14 21 22 23 T:0;
name:{T 1 4 up}
i: 13 14 15 23 32 T:1;
name:{T 1 4 right}
i: 15 22 23 24 33 T:1;
name:{T 1 4 down}
i: 14 23 31 32 33 T:1;
name:{T 1 4 left}
i: 13 22 23 24 31 T:1;
name:{C 1 4 up}
i: 14 15 23 32 33 T:0;
name:{C 1 4 right}
i: 22 23 24 31 33 T:0;
name:{C 1 4 down}
i: 13 14 23 31 32 T:0;
name:{C 1 4 left}
i: 13 15 22 23 24 T:0;
name:{T 1 5 up}
i: 14 15 16 24 33 T:1;
name:{T 1 5 right}
i: 16 23 24 25 34 T:1;
name:{T 1 5 down}
i: 15 24 32 33 34 T:1;
name:{T 1 5 left}
i: 14 23 24 25 32 T:1;
name:{C 1 5 up}
i: 15 16 24 33 34 T:0;
name:{C 1 5 right}
i: 23 24 25 32 34 T:0;
name:{C 1 5 down}
i: 14 15 24 32 33 T:0;
name:{C 1 5 left}
i: 14 16 23 24 25 T:0;
name:{T 1 6 up}
i: 15 16 17 25 34 T:1;
name:{T 1 6 right}
i: 17 24 25 26 35 T:1;
name:{T 1 6 down}
i: 16 25 33 34 35 T:1;
name:{T 1 6 left}
i: 15 24 25 26 33 T:1;
name:{C 1 6 up}
i: 16 17 25 34 35 T:0;
name:{C 1 6 right}
i: 24 25 26 33 35 T:0;
name:{C 1 6 down}
i: 15 16 25 33 34 T:0;
name:{C 1 6 left}
i: 15 17 24 25 26 T:0;
name:{T 2 0 up}
i: 18 19 20 28 37 T:1;
name:{T 2 0 right}
i: 20 27 28 29 38 T:1;
name:{T 2 0 down}
i: 19 28 36 37 38 T:1;
name:{T 2 0 left}
i: 18 27 28 29 36 T:1;
name:{C 2 0 up}
i: 19 20 28 37 38 T:0;
name:{C 2 0 right}
i: 27 28 29 36 38 T:0;
name:{C 2 0 down}
i: 18 19 28 36 37 T:0;
name:{C 2 0 left}
i: 18 20 27 28 29 T:0;
name:{T 2 1 up}
i: 19 20 21 29 38 T:1;
name:{T 2 1 right}
i: 21 28 29 30 39 T:1;
name:{T 2 1 down}
i: 20 29 37 38 39 T:1;
name:{T 2 1 left}
i: 19 28 29 30 37 T:1;
name:{C 2 1 up}
i: 20 21 29 38 39 T:0;
name:{C 2 1 right}
i: 28 29 30 37 39 T:0;
name:{C 2 1 down}
i: 19 20 29 37 38 T:0;
name:{C 2 1 left}
i: 19 21 28 29 30 T:0;
name:{T 2 2 up}
i: 20 21 22 30 39 T:1;
name:{T 2 2 right}
i: 22 29 30 31 40 T:1;
name:{T 2 2 down}
i: 21 30 38 39 40 T:1;
name:{T 2 2 left}
i: 20 29 30 31 38 T:1;
name:{C 2 2 up}
i: 21 22 30 39 40 T:0;
name:{C 2 2 right}
i: 29 30 31 38 40 T:0;
name:{C 2 2 down}
i: 20 21 30 38 39 T:0;
name:{C 2 2 left}
i: 20 22 29 30 31 T:0;
name:{T 2 3 up}
i: 21 22 23 31 40 T:1;
name:{T 2 3 right}
i: 23 30 31 32 41 T:1;
name:{T 2 3 down}
i: 22 31 39 40 41 T:1;
name:{T 2 3 left}
i: 21 30 31 32 39 T:1;
name:{C 2 3 up}
i: 22 23 31 40 41 T:0;
name:{C 2 3 right}
i: 30 31 32 39 41 T:0;
name:{C 2 3 down}
i: 21 22 31 39 40 T:0;
name:{C 2 3 left}
i: 21 23 30 31 32 T:0;
name:{T 2 4 up}
i: 22 23 24 32 41 T:1;
name:{T 2 4 right}
i: 24 31 32 33 42 T:1;
name:{T 2 4 down}
i: 23 32 40 41 42 T:1;
name:{T 2 4 left}
i: 22 31 32 33 40 T:1;
name:{C 2 4 up}
i: 23 24 32 41 42 T:0;
name:{C 2 4 right}
i: 31 32 33 40 42 T:0;
name:{C 2 4 down}
i: 22 23 32 40 41 T:0;
name:{C 2 4 left}
i: 22 24 31 32 33 T:0;
name:{T 2 5 up}
i: 23 24 25 33 42 T:1;
name:{T 2 5 right}
i: 25 32 33 34 43 T:1;
name:{T 2 5 down}
i: 24 33 41 42 43 T:1;
name:{T 2 5 left}
i: 23 32 33 34 41 T:1;
name:{C 2 5 up}
i: 24 25 33 42 43 T:0;
name:{C 2 5 right}
i: 32 33 34 41 43 T:0;
name:{C 2 5 down}
i: 23 24 33 41 42 T:0;
name:{C 2 5 left}
i: 23 25 32 33 34 T:0;
name:{T 2 6 up}
i: 24 25 26 34 43 T:1;
name:{T 2 6 right}
i: 26 33 34 35 44 T:1;
name:{T 2 6 down}
i: 25 34 42 43 44 T:1;
name:{T 2 6 left}
i: 24 33 34 35 42 T:1;
name:{C 2 6 up}
i: 25 26 34 43 44 T:0;
name:{C 2 6 right}
i: 33 34 35 42 44 T:0;
name:{C 2 6 down}
i: 24 25 34 42 43 T:0;
name:{C 2 6 left}
i: 24 26 33 34 35 T:0;
name:{T 3 0 up}
i: 27 28 29 37 46 T:1;
name:{T 3 0 right}
i: 29 36 37 38 47 T:1;
name:{T 3 0 down}
i: 28 37 45 46 47 T:1;
name:{T 3 0 left}
i: 27 36 37 38 45 T:1;
name:{C 3 0 up}
i: 28 29 37 46 47 T:0;
name:{C 3 0 right}
i: 36 37 38 45 47 T:0;
name:{C 3 0 down}
i: 27 28 37 45 46 T:0;
name:{C 3 0 left}
i: 27 29 36 37 38 T:0;
name:{T 3 1 up}
i: 28 29 30 38 47 T:1;
name:{T 3 1 right}
i: 30 37 38 39 48 T:1;
name:{T 3 1 down}
i: 29 38 46 47 48 T:1;
name:{T 3 1 left}
i: 28 37 38 39 46 T:1;
name:{C 3 1 up}
i: 29 30 38 47 48 T:0;
name:{C 3 1 right}
i: 37 38 39 46 48 T:0;
name:{C 3 1 down}
i: 28 29 38 46 47 T:0;
name:{C 3 1 left}
i: 28 30 37 38 39 T:0;
name:{T 3 2 up}
i: 29 30 31 39 48 T:1;
name:{T 3 2 right}
i: 31 38 39 40 49 T:1;
name:{T 3 2 down}
i: 30 39 47 48 49 T:1;
name:{T 3 2 left}
i: 29 38 39 40 47 T:1;
name:{C 3 2 up}
i: 30 31 39 48 49 T:0;
name:{C 3 2 right}
i: 38 39 40 47 49 T:0;
name:{C 3 2 down}
i: 29 30 39 47 48 T:0;
name:{C 3 2 left}
i: 29 31 38 39 40 T:0;
name:{T 3 3 up}
i: 30 31 32 40 49 T:1;
name:{T 3 3 right}
i: 32 39 40 41 50 T:1;
name:{T 3 3 down}
i: 31 40 48 49 50 T:1;
name:{T 3 3 left}
i: 30 39 40 41 48 T:1;
name:{C 3 3 up}
i: 31 32 40 49 50 T:0;
name:{C 3 3 right}
i: 39 40 41 48 50 T:0;
name:{C 3 3 down}
i: 30 31 40 48 49 T:0;
name:{C 3 3 left}
i: 30 32 39 40 41 T:0;
name:{T 3 4 up}
i: 31 32 33 41 50 T:1;
name:{T 3 4 right}
i: 33 40 41 42 51 T:1;
name:{T 3 4 down}
i: 32 41 49 50 51 T:1;
name:{T 3 4 left}
i: 31 40 41 42 49 T:1;
name:{C 3 4 up}
i: 32 33 41 50 51 T:0;
name:{C 3 4 right}
i: 40 41 42 49 51 T:0;
name:{C 3 4 down}
i: 31 32 41 49 50 T:0;
name:{C 3 4 left}
i: 31 33 40 41 42 T:0;
name:{T 3 5 up}
i: 32 33 34 42 51 T:1;
name:{T 3 5 right}
i: 34 41 42 43 52 T:1;
name:{T 3 5 down}
i: 33 42 50 51 52 T:1;
name:{T 3 5 left}
i: 32 41 42 43 50 T:1;
name:{C 3 5 up}
i: 33 34 42 51 52 T:0;
name:{C 3 5 right}
i: 41 42 43 50 52 T:0;
name:{C 3 5 down}
i: 32 33 42 50 51 T:0;
name:{C 3 5 left}
i: 32 34 41 42 43 T:0;
name:{T 3 6 up}
i: 33 34 35 43 52 T:1;
name:{T 3 6 right}
i: 35 42 43 44 53 T:1;
name:{T 3 6 down}
i: 34 43 51 52 53 T:1;
name:{T 3 6 left}
i: 33 42 43 44 51 T:1;
name:{C 3 6 up}
i: 34 35 43 52 53 T:0;
name:{C 3 6 right}
i: 42 43 44 51 53 T:0;
name:{C 3 6 down}
i: 33 34 43 51 52 T:0;
name:{C 3 6 left}
i: 33 35 42 43 44 T:0;
name:{T 4 0 up}
i: 36 37 38 46 55 T:1;
name:{T 4 0 right}
i: 38 45 46 47 56 T:1;
name:{T 4 0 down}
i: 37 46 54 55 56 T:1;
name:{T 4 0 left}
i: 36 45 46 47 54 T:1;
name:{C 4 0 up}
i: 37 38 46 55 56 T:0;
name:{C 4 0 right}
i: 45 46 47 54 56 T:0;
name:{C 4 0 down}
i: 36 37 46 54 55 T:0;
name:{C 4 0 left}
i: 36 38 45 46 47 T:0;
name:{T 4 1 up}
i: 37 38 39 47 56 T:1;
name:{T 4 1 right}
i: 39 46 47 48 57 T:1;
name:{T 4 1 down}
i: 38 47 55 56 57 T:1;
name:{T 4 1 left}
i: 37 46 47 48 55 T:1;
name:{C 4 1 up}
i: 38 39 47 56 57 T:0;
name:{C 4 1 right}
i: 46 47 48 55 57 T:0;
name:{C 4 1 down}
i: 37 38 47 55 56 T:0;
name:{C 4 1 left}
i: 37 39 46 47 48 T:0;
name:{T 4 2 up}
i: 38 39 40 48 57 T:1;
name:{T 4 2 right}
i: 40 47 48 49 58 T:1;
name:{T 4 2 down}
i: 39 48 56 57 58 T:1;
name:{T 4 2 left}
i: 38 47 48 49 56 T:1;
name:{C 4 2 up}
i: 39 40 48 57 58 T:0;
name:{C 4 2 right}
i: 47 48 49 56 58 T:0;
name:{C 4 2 down}
i: 38 39 48 56 57 T:0;
name:{C 4 2 left}
i: 38 40 47 48 49 T:0;
name:{T 4 3 up}
i: 39 40 41 49 58 T:1;
name:{T 4 3 right}
i: 41 48 49 50 59 T:1;
name:{T 4 3 down}
i: 40 49 57 58 59 T:1;
name:{T 4 3 left}
i: 39 48 49 50 57 T:1;
name:{C 4 3 up}
i: 40 41 49 58 59 T:0;
name:{C 4 3 right}
i: 48 49 50 57 59 T:0;
name:{C 4 3 down}
i: 39 40 49 57 58 T:0;
name:{C 4 3 left}
i: 39 41 48 49 50 T:0;
name:{T 4 4 up}
i: 40 41 42 50 59 T:1;
name:{T 4 4 right}
i: 42 49 50 51 60 T:1;
name:{T 4 4 down}
i: 41 50 58 59 60 T:1;
name:{T 4 4 left}
i: 40 49 50 51 58 T:1;
name:{C 4 4 up}
i: 41 42 50 59 60 T:0;
name:{C 4 4 right}
i: 49 50 51 58 60 T:0;
name:{C 4 4 down}
i: 40 41 50 58 59 T:0;
name:{C 4 4 left}
i: 40 42 49 50 51 T:0;
name:{T 4 5 up}
i: 41 42 43 51 60 T:1;
name:{T 4 5 right}
i: 43 50 51 52 61 T:1;
name:{T 4 5 down}
i: 42 51 59 60 61 T:1;
name:{T 4 5 left}
i: 41 50 51 52 59 T:1;
name:{C 4 5 up}
i: 42 43 51 60 61 T:0;
name:{C 4 5 right}
i: 50 51 52 59 61 T:0;
name:{C 4 5 down}
i: 41 42 51 59 60 T:0;
name:{C 4 5 left}
i: 41 43 50 51 52 T:0;
name:{T 4 6 up}
i: 42 43 44 52 61 T:1;
name:{T 4 6 right}
i: 44 51 52 53 62 T:1;
name:{T 4 6 down}
i: 43 52 60 61 62 T:1;
name:{T 4 6 left}
i: 42 51 52 53 60 T:1;
name:{C 4 6 up}
i: 43 44 52 61 62 T:0;
name:{C 4 6 right}
i: 51 52 53 60 62 T:0;
name:{C 4 6 down}
i: 42 43 52 60 61 T:0;
name:{C 4 6 left}
i: 42 44 51 52 53 T:0;
name:{T 5 0 up}
i: 45 46 47 55 64 T:1;
name:{T 5 0 right}
i: 47 54 55 56 65 T:1;
name:{T 5 0 down}
i: 46 55 63 64 65 T:1;
name:{T 5 0 left}
i: 45 54 55 56 63 T:1;
name:{C 5 0 up}
i: 46 47 55 64 65 T:0;
name:{C 5 0 right}
i: 54 55 56 63 65 T:0;
name:{C 5 0 down}
i: 45 46 55 63 64 T:0;
name:{C 5 0 left}
i: 45 47 54 55 56 T:0;
name:{T 5 1 up}
i: 46 47 48 56 65 T:1;
name:{T 5 1 right}
i: 48 55 56 57 66 T:1;
name:{T 5 1 down}
i: 47 56 64 65 66 T:1;
name:{T 5 1 left}
i: 46 55 56 57 64 T:1;
name:{C 5 1 up}
i: 47 48 56 65 66 T:0;
name:{C 5 1 right}
i: 55 56 57 64 66 T:0;
name:{C 5 1 down}
i: 46 47 56 64 65 T:0;
name:{C 5 1 left}
i: 46 48 55 56 57 T:0;
name:{T 5 2 up}
i: 47 48 49 57 66 T:1;
name:{T 5 2 right}
i: 49 56 57 58 67 T:1;
name:{T 5 2 down}
i: 48 57 65 66 67 T:1;
name:{T 5 2 left}
i: 47 56 57 58 65 T:1;
name:{C 5 2 up}
i: 48 49 57 66 67 T:0;
name:{C 5 2 right}
i: 56 57 58 65 67 T:0;
name:{C 5 2 down}
i: 47 48 57 65 66 T:0;
name:{C 5 2 left}
i: 47 49 56 57 58 T:0;
name:{T 5 3 up}
i: 48 49 50 58 67 T:1;
name:{T 5 3 right}
i: 50 57 58 59 68 T:1;
name:{T 5 3 down}
i: 49 58 66 67 68 T:1;
name:{T 5 3 left}
i: 48 57 58 59 66 T:1;
name:{C 5 3 up}
i: 49 50 58 67 68 T:0;
name:{C 5 3 right}
i: 57 58 59 66 68 T:0;
name:{C 5 3 down}
i: 48 49 58 66 67 T:0;
name:{C 5 3 left}
i: 48 50 57 58 59 T:0;
name:{T 5 4 up}
i: 49 50 51 59 68 T:1;
name:{T 5 4 right}
i: 51 58 59 60 69 T:1;
name:{T 5 4 down}
i: 50 59 67 68 69 T:1;
name:{T 5 4 left}
i: 49 58 59 60 67 T:1;
name:{C 5 4 up}
i: 50 51 59 68 69 T:0;
name:{C 5 4 right}
i: 58 59 60 67 69 T:0;
name:{C 5 4 down}
i: 49 50 59 67 68 T:0;
name:{C 5 4 left}
i: 49 51 58 59 60 T:0;
name:{T 5 5 up}
i: 50 51 52 60 69 T:1;
name:{T 5 5 right}
i: 52 59 60 61 70 T:1;
name:{T 5 5 down}
i: 51 60 68 69 70 T:1;
name:{T 5 5 left}
i: 50 59 60 61 68 T:1;
name:{C 5 5 up}
i: 51 52 60 69 70 T:0;
name:{C 5 5 right}
i: 59 60 61 68 70 T:0;
name:{C 5 5 down}
i: 50 51 60 68 69 T:0;
name:{C 5 5 left}
i: 50 52 59 60 61 T:0;
name:{T 5 6 up}
i: 51 52 53 61 70 T:1;
name:{T 5 6 right}
i: 53 60 61 62 71 T:1;
name:{T 5 6 down}
i: 52 61 69 70 71 T:1;
name:{T 5 6 left}
i: 51 60 61 62 69 T:1;
name:{C 5 6 up}
i: 52 53 61 70 71 T:0;
name:{C 5 6 right}
i: 60 61 62 69 71 T:0;
name:{C 5 6 down}
i: 51 52 61 69 70 T:0;
name:{C 5 6 left}
i: 51 53 60 61 62 T:0;
name:{T 6 0 up}
i: 54 55 56 64 73 T:1;
name:{T 6 0 right}
i: 56 63 64 65 74 T:1;
name:{T 6 0 down}
i: 55 64 72 73 74 T:1;
name:{T 6 0 left}
i: 54 63 64 65 72 T:1;
name:{C 6 0 up}
i: 55 56 64 73 74 T:0;
name:{C 6 0 right}
i: 63 64 65 72 74 T:0;
name:{C 6 0 down}
i: 54 55 64 72 73 T:0;
name:{C 6 0 left}
i: 54 56 63 64 65 T:0;
name:{T 6 1 up}
i: 55 56 57 65 74 T:1;
name:{T 6 1 right}
i: 57 64 65 66 75 T:1;
name:{T 6 1 down}
i: 56 65 73 74 75 T:1;
name:{T 6 1 left}
i: 55 64 65 66 73 T:1;
name:{C 6 1 up}
i: 56 57 65 74 75 T:0;
name:{C 6 1 right}
i: 64 65 66 73 75 T:0;
name:{C 6 1 down}
i: 55 56 65 73 74 T:0;
name:{C 6 1 left}
i: 55 57 64 65 66 T:0;
name:{T 6 2 up}
i: 56 57 58 66 75 T:1;
name:{T 6 2 right}
i: 58 65 66 67 76 T:1;
name:{T 6 2 down}
i: 57 66 74 75 76 T:1;
name:{T 6 2 left}
i: 56 65 66 67 74 T:1;
name:{C 6 2 up}
i: 57 58 66 75 76 T:0;
name:{C 6 2 right}
i: 65 66 67 74 76 T:0;
name:{C 6 2 down}
i: 56 57 66 74 75 T:0;
name:{C 6 2 left}
i: 56 58 65 66 67 T:0;
name:{T 6 3 up}
i: 57 58 59 67 76 T:1;
name:{T 6 3 right}
i: 59 66 67 68 77 T:1;
name:{T 6 3 down}
i: 58 67 75 76 77 T:1;
name:{T 6 3 left}
i: 57 66 67 68 75 T:1;
name:{C 6 3 up}
i: 58 59 67 76 77 T:0;
name:{C 6 3 right}
i: 66 67 68 75 77 T:0;
name:{C 6 3 down}
i: 57 58 67 75 76 T:0;
name:{C 6 3 left}
i: 57 59 66 67 68 T:0;
name:{T 6 4 up}
i: 58 59 60 68 77 T:1;
name:{T 6 4 right}
i: 60 67 68 69 78 T:1;
name:{T 6 4 down}
i: 59 68 76 77 78 T:1;
name:{T 6 4 left}
i: 58 67 68 69 76 T:1;
name:{C 6 4 up}
i: 59 60 68 77 78 T:0;
name:{C 6 4 right}
i: 67 68 69 76 78 T:0;
name:{C 6 4 down}
i: 58 59 68 76 77 T:0;
name:{C 6 4 left}
i: 58 60 67 68 69 T:0;
name:{T 6 5 up}
i: 59 60 61 69 78 T:1;
name:{T 6 5 right}
i: 61 68 69 70 79 T:1;
name:{T 6 5 down}
i: 60 69 77 78 79 T:1;
name:{T 6 5 left}
i: 59 68 69 70 77 T:1;
name:{C 6 5 up}
i: 60 61 69 78 79 T:0;
name:{C 6 5 right}
i: 68 69 70 77 79 T:0;
name:{C 6 5 down}
i: 59 60 69 77 78 T:0;
name:{C 6 5 left}
i: 59 61 68 69 70 T:0;
name:{T 6 6 up}
i: 60 61 62 70 79 T:1;
name:{T 6 6 right}
i: 62 69 70 71 80 T:1;
name:{T 6 6 down}
i: 61 70 78 79 80 T:1;
name:{T 6 6 left}
i: 60 69 70 71 78 T:1;
name:{C 6 6 up}
i: 61 62 70 79 80 T:0;
name:{C 6 6 right}
i: 69 70 71 78 80 T:0;
name:{C 6 6 down}
i: 60 61 70 78 79 T:0;
name:{C 6 6 left}
i: 60 62 69 70 71 T:0;
