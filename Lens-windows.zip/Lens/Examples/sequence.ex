name: {0 1 2 0 1 2 0 1 2} 9
i:0 t:5
i:1 t:5
i:2 t:0
i:0 t:1
i:1 t:2
i:2 t:0
i:0 t:1
i:1 t:2
i:2 t:0;
name: {0 1 3 0 1 3 0 1 3} 9
i:0 t:5
i:1 t:5
i:3 t:0
i:0 t:1
i:1 t:3
i:3 t:0
i:0 t:1
i:1 t:3
i:3 t:0;
name: {0 1 4 0 1 4 0 1 4} 9
i:0 t:5
i:1 t:5
i:4 t:0
i:0 t:1
i:1 t:4
i:4 t:0
i:0 t:1
i:1 t:4
i:4 t:0;
name: {0 2 1 0 2 1 0 2 1} 9
i:0 t:5
i:2 t:5
i:1 t:0
i:0 t:2
i:2 t:1
i:1 t:0
i:0 t:2
i:2 t:1
i:1 t:0;
name: {0 2 3 0 2 3 0 2 3} 9
i:0 t:5
i:2 t:5
i:3 t:0
i:0 t:2
i:2 t:3
i:3 t:0
i:0 t:2
i:2 t:3
i:3 t:0;
name: {0 2 4 0 2 4 0 2 4} 9
i:0 t:5
i:2 t:5
i:4 t:0
i:0 t:2
i:2 t:4
i:4 t:0
i:0 t:2
i:2 t:4
i:4 t:0;
name: {0 3 1 0 3 1 0 3 1} 9
i:0 t:5
i:3 t:5
i:1 t:0
i:0 t:3
i:3 t:1
i:1 t:0
i:0 t:3
i:3 t:1
i:1 t:0;
name: {0 3 2 0 3 2 0 3 2} 9
i:0 t:5
i:3 t:5
i:2 t:0
i:0 t:3
i:3 t:2
i:2 t:0
i:0 t:3
i:3 t:2
i:2 t:0;
name: {0 3 4 0 3 4 0 3 4} 9
i:0 t:5
i:3 t:5
i:4 t:0
i:0 t:3
i:3 t:4
i:4 t:0
i:0 t:3
i:3 t:4
i:4 t:0;
name: {0 4 1 0 4 1 0 4 1} 9
i:0 t:5
i:4 t:5
i:1 t:0
i:0 t:4
i:4 t:1
i:1 t:0
i:0 t:4
i:4 t:1
i:1 t:0;
name: {0 4 2 0 4 2 0 4 2} 9
i:0 t:5
i:4 t:5
i:2 t:0
i:0 t:4
i:4 t:2
i:2 t:0
i:0 t:4
i:4 t:2
i:2 t:0;
name: {0 4 3 0 4 3 0 4 3} 9
i:0 t:5
i:4 t:5
i:3 t:0
i:0 t:4
i:4 t:3
i:3 t:0
i:0 t:4
i:4 t:3
i:3 t:0;
name: {1 0 2 1 0 2 1 0 2} 9
i:1 t:5
i:0 t:5
i:2 t:1
i:1 t:0
i:0 t:2
i:2 t:1
i:1 t:0
i:0 t:2
i:2 t:1;
name: {1 0 3 1 0 3 1 0 3} 9
i:1 t:5
i:0 t:5
i:3 t:1
i:1 t:0
i:0 t:3
i:3 t:1
i:1 t:0
i:0 t:3
i:3 t:1;
name: {1 0 4 1 0 4 1 0 4} 9
i:1 t:5
i:0 t:5
i:4 t:1
i:1 t:0
i:0 t:4
i:4 t:1
i:1 t:0
i:0 t:4
i:4 t:1;
name: {1 2 0 1 2 0 1 2 0} 9
i:1 t:5
i:2 t:5
i:0 t:1
i:1 t:2
i:2 t:0
i:0 t:1
i:1 t:2
i:2 t:0
i:0 t:1;
name: {1 2 3 1 2 3 1 2 3} 9
i:1 t:5
i:2 t:5
i:3 t:1
i:1 t:2
i:2 t:3
i:3 t:1
i:1 t:2
i:2 t:3
i:3 t:1;
name: {1 2 4 1 2 4 1 2 4} 9
i:1 t:5
i:2 t:5
i:4 t:1
i:1 t:2
i:2 t:4
i:4 t:1
i:1 t:2
i:2 t:4
i:4 t:1;
name: {1 3 0 1 3 0 1 3 0} 9
i:1 t:5
i:3 t:5
i:0 t:1
i:1 t:3
i:3 t:0
i:0 t:1
i:1 t:3
i:3 t:0
i:0 t:1;
name: {1 3 2 1 3 2 1 3 2} 9
i:1 t:5
i:3 t:5
i:2 t:1
i:1 t:3
i:3 t:2
i:2 t:1
i:1 t:3
i:3 t:2
i:2 t:1;
name: {1 3 4 1 3 4 1 3 4} 9
i:1 t:5
i:3 t:5
i:4 t:1
i:1 t:3
i:3 t:4
i:4 t:1
i:1 t:3
i:3 t:4
i:4 t:1;
name: {1 4 0 1 4 0 1 4 0} 9
i:1 t:5
i:4 t:5
i:0 t:1
i:1 t:4
i:4 t:0
i:0 t:1
i:1 t:4
i:4 t:0
i:0 t:1;
name: {1 4 2 1 4 2 1 4 2} 9
i:1 t:5
i:4 t:5
i:2 t:1
i:1 t:4
i:4 t:2
i:2 t:1
i:1 t:4
i:4 t:2
i:2 t:1;
name: {1 4 3 1 4 3 1 4 3} 9
i:1 t:5
i:4 t:5
i:3 t:1
i:1 t:4
i:4 t:3
i:3 t:1
i:1 t:4
i:4 t:3
i:3 t:1;
name: {2 0 1 2 0 1 2 0 1} 9
i:2 t:5
i:0 t:5
i:1 t:2
i:2 t:0
i:0 t:1
i:1 t:2
i:2 t:0
i:0 t:1
i:1 t:2;
name: {2 0 3 2 0 3 2 0 3} 9
i:2 t:5
i:0 t:5
i:3 t:2
i:2 t:0
i:0 t:3
i:3 t:2
i:2 t:0
i:0 t:3
i:3 t:2;
name: {2 0 4 2 0 4 2 0 4} 9
i:2 t:5
i:0 t:5
i:4 t:2
i:2 t:0
i:0 t:4
i:4 t:2
i:2 t:0
i:0 t:4
i:4 t:2;
name: {2 1 0 2 1 0 2 1 0} 9
i:2 t:5
i:1 t:5
i:0 t:2
i:2 t:1
i:1 t:0
i:0 t:2
i:2 t:1
i:1 t:0
i:0 t:2;
name: {2 1 3 2 1 3 2 1 3} 9
i:2 t:5
i:1 t:5
i:3 t:2
i:2 t:1
i:1 t:3
i:3 t:2
i:2 t:1
i:1 t:3
i:3 t:2;
name: {2 1 4 2 1 4 2 1 4} 9
i:2 t:5
i:1 t:5
i:4 t:2
i:2 t:1
i:1 t:4
i:4 t:2
i:2 t:1
i:1 t:4
i:4 t:2;
name: {2 3 0 2 3 0 2 3 0} 9
i:2 t:5
i:3 t:5
i:0 t:2
i:2 t:3
i:3 t:0
i:0 t:2
i:2 t:3
i:3 t:0
i:0 t:2;
name: {2 3 1 2 3 1 2 3 1} 9
i:2 t:5
i:3 t:5
i:1 t:2
i:2 t:3
i:3 t:1
i:1 t:2
i:2 t:3
i:3 t:1
i:1 t:2;
name: {2 3 4 2 3 4 2 3 4} 9
i:2 t:5
i:3 t:5
i:4 t:2
i:2 t:3
i:3 t:4
i:4 t:2
i:2 t:3
i:3 t:4
i:4 t:2;
name: {2 4 0 2 4 0 2 4 0} 9
i:2 t:5
i:4 t:5
i:0 t:2
i:2 t:4
i:4 t:0
i:0 t:2
i:2 t:4
i:4 t:0
i:0 t:2;
name: {2 4 1 2 4 1 2 4 1} 9
i:2 t:5
i:4 t:5
i:1 t:2
i:2 t:4
i:4 t:1
i:1 t:2
i:2 t:4
i:4 t:1
i:1 t:2;
name: {2 4 3 2 4 3 2 4 3} 9
i:2 t:5
i:4 t:5
i:3 t:2
i:2 t:4
i:4 t:3
i:3 t:2
i:2 t:4
i:4 t:3
i:3 t:2;
name: {3 0 1 3 0 1 3 0 1} 9
i:3 t:5
i:0 t:5
i:1 t:3
i:3 t:0
i:0 t:1
i:1 t:3
i:3 t:0
i:0 t:1
i:1 t:3;
name: {3 0 2 3 0 2 3 0 2} 9
i:3 t:5
i:0 t:5
i:2 t:3
i:3 t:0
i:0 t:2
i:2 t:3
i:3 t:0
i:0 t:2
i:2 t:3;
name: {3 0 4 3 0 4 3 0 4} 9
i:3 t:5
i:0 t:5
i:4 t:3
i:3 t:0
i:0 t:4
i:4 t:3
i:3 t:0
i:0 t:4
i:4 t:3;
name: {3 1 0 3 1 0 3 1 0} 9
i:3 t:5
i:1 t:5
i:0 t:3
i:3 t:1
i:1 t:0
i:0 t:3
i:3 t:1
i:1 t:0
i:0 t:3;
name: {3 1 2 3 1 2 3 1 2} 9
i:3 t:5
i:1 t:5
i:2 t:3
i:3 t:1
i:1 t:2
i:2 t:3
i:3 t:1
i:1 t:2
i:2 t:3;
name: {3 1 4 3 1 4 3 1 4} 9
i:3 t:5
i:1 t:5
i:4 t:3
i:3 t:1
i:1 t:4
i:4 t:3
i:3 t:1
i:1 t:4
i:4 t:3;
name: {3 2 0 3 2 0 3 2 0} 9
i:3 t:5
i:2 t:5
i:0 t:3
i:3 t:2
i:2 t:0
i:0 t:3
i:3 t:2
i:2 t:0
i:0 t:3;
name: {3 2 1 3 2 1 3 2 1} 9
i:3 t:5
i:2 t:5
i:1 t:3
i:3 t:2
i:2 t:1
i:1 t:3
i:3 t:2
i:2 t:1
i:1 t:3;
name: {3 2 4 3 2 4 3 2 4} 9
i:3 t:5
i:2 t:5
i:4 t:3
i:3 t:2
i:2 t:4
i:4 t:3
i:3 t:2
i:2 t:4
i:4 t:3;
name: {3 4 0 3 4 0 3 4 0} 9
i:3 t:5
i:4 t:5
i:0 t:3
i:3 t:4
i:4 t:0
i:0 t:3
i:3 t:4
i:4 t:0
i:0 t:3;
name: {3 4 1 3 4 1 3 4 1} 9
i:3 t:5
i:4 t:5
i:1 t:3
i:3 t:4
i:4 t:1
i:1 t:3
i:3 t:4
i:4 t:1
i:1 t:3;
name: {3 4 2 3 4 2 3 4 2} 9
i:3 t:5
i:4 t:5
i:2 t:3
i:3 t:4
i:4 t:2
i:2 t:3
i:3 t:4
i:4 t:2
i:2 t:3;
name: {4 0 1 4 0 1 4 0 1} 9
i:4 t:5
i:0 t:5
i:1 t:4
i:4 t:0
i:0 t:1
i:1 t:4
i:4 t:0
i:0 t:1
i:1 t:4;
name: {4 0 2 4 0 2 4 0 2} 9
i:4 t:5
i:0 t:5
i:2 t:4
i:4 t:0
i:0 t:2
i:2 t:4
i:4 t:0
i:0 t:2
i:2 t:4;
name: {4 0 3 4 0 3 4 0 3} 9
i:4 t:5
i:0 t:5
i:3 t:4
i:4 t:0
i:0 t:3
i:3 t:4
i:4 t:0
i:0 t:3
i:3 t:4;
name: {4 1 0 4 1 0 4 1 0} 9
i:4 t:5
i:1 t:5
i:0 t:4
i:4 t:1
i:1 t:0
i:0 t:4
i:4 t:1
i:1 t:0
i:0 t:4;
name: {4 1 2 4 1 2 4 1 2} 9
i:4 t:5
i:1 t:5
i:2 t:4
i:4 t:1
i:1 t:2
i:2 t:4
i:4 t:1
i:1 t:2
i:2 t:4;
name: {4 1 3 4 1 3 4 1 3} 9
i:4 t:5
i:1 t:5
i:3 t:4
i:4 t:1
i:1 t:3
i:3 t:4
i:4 t:1
i:1 t:3
i:3 t:4;
name: {4 2 0 4 2 0 4 2 0} 9
i:4 t:5
i:2 t:5
i:0 t:4
i:4 t:2
i:2 t:0
i:0 t:4
i:4 t:2
i:2 t:0
i:0 t:4;
name: {4 2 1 4 2 1 4 2 1} 9
i:4 t:5
i:2 t:5
i:1 t:4
i:4 t:2
i:2 t:1
i:1 t:4
i:4 t:2
i:2 t:1
i:1 t:4;
name: {4 2 3 4 2 3 4 2 3} 9
i:4 t:5
i:2 t:5
i:3 t:4
i:4 t:2
i:2 t:3
i:3 t:4
i:4 t:2
i:2 t:3
i:3 t:4;
name: {4 3 0 4 3 0 4 3 0} 9
i:4 t:5
i:3 t:5
i:0 t:4
i:4 t:3
i:3 t:0
i:0 t:4
i:4 t:3
i:3 t:0
i:0 t:4;
name: {4 3 1 4 3 1 4 3 1} 9
i:4 t:5
i:3 t:5
i:1 t:4
i:4 t:3
i:3 t:1
i:1 t:4
i:4 t:3
i:3 t:1
i:1 t:4;
name: {4 3 2 4 3 2 4 3 2} 9
i:4 t:5
i:3 t:5
i:2 t:4
i:4 t:3
i:3 t:2
i:2 t:4
i:4 t:3
i:3 t:2
i:2 t:4;
