min:0.5;
name:{A on-off}
2 b:0;
name:{B on-off}
2 b:1;
name:{C on-off}
2 b:2;
name:{D on-off}
2 b:3;
name:{E on-off}
2 b:4;
name:{F on-off}
2 b:5;
