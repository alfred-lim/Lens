name: {a a a a a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 0
t: 0 4 8 12
i: 0
t: 0 4 8 12 16;
name: {a a a a b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 0
t: 0 4 8 12
i: 1
t: 0 4 8 12 17;
name: {a a a a c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 0
t: 0 4 8 12
i: 2
t: 0 4 8 12 18;
name: {a a a a d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 0
t: 0 4 8 12
i: 3
t: 0 4 8 12 19;
name: {a a a b a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 1
t: 0 4 8 13
i: 0
t: 0 4 8 13 16;
name: {a a a b b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 1
t: 0 4 8 13
i: 1
t: 0 4 8 13 17;
name: {a a a b c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 1
t: 0 4 8 13
i: 2
t: 0 4 8 13 18;
name: {a a a b d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 1
t: 0 4 8 13
i: 3
t: 0 4 8 13 19;
name: {a a a c a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 2
t: 0 4 8 14
i: 0
t: 0 4 8 14 16;
name: {a a a c b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 2
t: 0 4 8 14
i: 1
t: 0 4 8 14 17;
name: {a a a c c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 2
t: 0 4 8 14
i: 2
t: 0 4 8 14 18;
name: {a a a c d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 2
t: 0 4 8 14
i: 3
t: 0 4 8 14 19;
name: {a a a d a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 3
t: 0 4 8 15
i: 0
t: 0 4 8 15 16;
name: {a a a d b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 3
t: 0 4 8 15
i: 1
t: 0 4 8 15 17;
name: {a a a d c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 3
t: 0 4 8 15
i: 2
t: 0 4 8 15 18;
name: {a a a d d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 0
t: 0 4 8
i: 3
t: 0 4 8 15
i: 3
t: 0 4 8 15 19;
name: {a a b a a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 0
t: 0 4 9 12
i: 0
t: 0 4 9 12 16;
name: {a a b a b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 0
t: 0 4 9 12
i: 1
t: 0 4 9 12 17;
name: {a a b a c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 0
t: 0 4 9 12
i: 2
t: 0 4 9 12 18;
name: {a a b a d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 0
t: 0 4 9 12
i: 3
t: 0 4 9 12 19;
name: {a a b b a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 1
t: 0 4 9 13
i: 0
t: 0 4 9 13 16;
name: {a a b b b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 1
t: 0 4 9 13
i: 1
t: 0 4 9 13 17;
name: {a a b b c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 1
t: 0 4 9 13
i: 2
t: 0 4 9 13 18;
name: {a a b b d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 1
t: 0 4 9 13
i: 3
t: 0 4 9 13 19;
name: {a a b c a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 2
t: 0 4 9 14
i: 0
t: 0 4 9 14 16;
name: {a a b c b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 2
t: 0 4 9 14
i: 1
t: 0 4 9 14 17;
name: {a a b c c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 2
t: 0 4 9 14
i: 2
t: 0 4 9 14 18;
name: {a a b c d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 2
t: 0 4 9 14
i: 3
t: 0 4 9 14 19;
name: {a a b d a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 3
t: 0 4 9 15
i: 0
t: 0 4 9 15 16;
name: {a a b d b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 3
t: 0 4 9 15
i: 1
t: 0 4 9 15 17;
name: {a a b d c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 3
t: 0 4 9 15
i: 2
t: 0 4 9 15 18;
name: {a a b d d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 1
t: 0 4 9
i: 3
t: 0 4 9 15
i: 3
t: 0 4 9 15 19;
name: {a a c a a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 0
t: 0 4 10 12
i: 0
t: 0 4 10 12 16;
name: {a a c a b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 0
t: 0 4 10 12
i: 1
t: 0 4 10 12 17;
name: {a a c a c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 0
t: 0 4 10 12
i: 2
t: 0 4 10 12 18;
name: {a a c a d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 0
t: 0 4 10 12
i: 3
t: 0 4 10 12 19;
name: {a a c b a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 1
t: 0 4 10 13
i: 0
t: 0 4 10 13 16;
name: {a a c b b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 1
t: 0 4 10 13
i: 1
t: 0 4 10 13 17;
name: {a a c b c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 1
t: 0 4 10 13
i: 2
t: 0 4 10 13 18;
name: {a a c b d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 1
t: 0 4 10 13
i: 3
t: 0 4 10 13 19;
name: {a a c c a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 2
t: 0 4 10 14
i: 0
t: 0 4 10 14 16;
name: {a a c c b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 2
t: 0 4 10 14
i: 1
t: 0 4 10 14 17;
name: {a a c c c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 2
t: 0 4 10 14
i: 2
t: 0 4 10 14 18;
name: {a a c c d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 2
t: 0 4 10 14
i: 3
t: 0 4 10 14 19;
name: {a a c d a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 3
t: 0 4 10 15
i: 0
t: 0 4 10 15 16;
name: {a a c d b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 3
t: 0 4 10 15
i: 1
t: 0 4 10 15 17;
name: {a a c d c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 3
t: 0 4 10 15
i: 2
t: 0 4 10 15 18;
name: {a a c d d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 2
t: 0 4 10
i: 3
t: 0 4 10 15
i: 3
t: 0 4 10 15 19;
name: {a a d a a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 0
t: 0 4 11 12
i: 0
t: 0 4 11 12 16;
name: {a a d a b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 0
t: 0 4 11 12
i: 1
t: 0 4 11 12 17;
name: {a a d a c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 0
t: 0 4 11 12
i: 2
t: 0 4 11 12 18;
name: {a a d a d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 0
t: 0 4 11 12
i: 3
t: 0 4 11 12 19;
name: {a a d b a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 1
t: 0 4 11 13
i: 0
t: 0 4 11 13 16;
name: {a a d b b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 1
t: 0 4 11 13
i: 1
t: 0 4 11 13 17;
name: {a a d b c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 1
t: 0 4 11 13
i: 2
t: 0 4 11 13 18;
name: {a a d b d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 1
t: 0 4 11 13
i: 3
t: 0 4 11 13 19;
name: {a a d c a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 2
t: 0 4 11 14
i: 0
t: 0 4 11 14 16;
name: {a a d c b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 2
t: 0 4 11 14
i: 1
t: 0 4 11 14 17;
name: {a a d c c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 2
t: 0 4 11 14
i: 2
t: 0 4 11 14 18;
name: {a a d c d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 2
t: 0 4 11 14
i: 3
t: 0 4 11 14 19;
name: {a a d d a} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 3
t: 0 4 11 15
i: 0
t: 0 4 11 15 16;
name: {a a d d b} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 3
t: 0 4 11 15
i: 1
t: 0 4 11 15 17;
name: {a a d d c} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 3
t: 0 4 11 15
i: 2
t: 0 4 11 15 18;
name: {a a d d d} 5
i: 0
t: 0
i: 0
t: 0 4
i: 3
t: 0 4 11
i: 3
t: 0 4 11 15
i: 3
t: 0 4 11 15 19;
name: {a b a a a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 0
t: 0 5 8 12
i: 0
t: 0 5 8 12 16;
name: {a b a a b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 0
t: 0 5 8 12
i: 1
t: 0 5 8 12 17;
name: {a b a a c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 0
t: 0 5 8 12
i: 2
t: 0 5 8 12 18;
name: {a b a a d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 0
t: 0 5 8 12
i: 3
t: 0 5 8 12 19;
name: {a b a b a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 1
t: 0 5 8 13
i: 0
t: 0 5 8 13 16;
name: {a b a b b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 1
t: 0 5 8 13
i: 1
t: 0 5 8 13 17;
name: {a b a b c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 1
t: 0 5 8 13
i: 2
t: 0 5 8 13 18;
name: {a b a b d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 1
t: 0 5 8 13
i: 3
t: 0 5 8 13 19;
name: {a b a c a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 2
t: 0 5 8 14
i: 0
t: 0 5 8 14 16;
name: {a b a c b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 2
t: 0 5 8 14
i: 1
t: 0 5 8 14 17;
name: {a b a c c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 2
t: 0 5 8 14
i: 2
t: 0 5 8 14 18;
name: {a b a c d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 2
t: 0 5 8 14
i: 3
t: 0 5 8 14 19;
name: {a b a d a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 3
t: 0 5 8 15
i: 0
t: 0 5 8 15 16;
name: {a b a d b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 3
t: 0 5 8 15
i: 1
t: 0 5 8 15 17;
name: {a b a d c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 3
t: 0 5 8 15
i: 2
t: 0 5 8 15 18;
name: {a b a d d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 0
t: 0 5 8
i: 3
t: 0 5 8 15
i: 3
t: 0 5 8 15 19;
name: {a b b a a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 0
t: 0 5 9 12
i: 0
t: 0 5 9 12 16;
name: {a b b a b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 0
t: 0 5 9 12
i: 1
t: 0 5 9 12 17;
name: {a b b a c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 0
t: 0 5 9 12
i: 2
t: 0 5 9 12 18;
name: {a b b a d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 0
t: 0 5 9 12
i: 3
t: 0 5 9 12 19;
name: {a b b b a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 1
t: 0 5 9 13
i: 0
t: 0 5 9 13 16;
name: {a b b b b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 1
t: 0 5 9 13
i: 1
t: 0 5 9 13 17;
name: {a b b b c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 1
t: 0 5 9 13
i: 2
t: 0 5 9 13 18;
name: {a b b b d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 1
t: 0 5 9 13
i: 3
t: 0 5 9 13 19;
name: {a b b c a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 2
t: 0 5 9 14
i: 0
t: 0 5 9 14 16;
name: {a b b c b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 2
t: 0 5 9 14
i: 1
t: 0 5 9 14 17;
name: {a b b c c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 2
t: 0 5 9 14
i: 2
t: 0 5 9 14 18;
name: {a b b c d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 2
t: 0 5 9 14
i: 3
t: 0 5 9 14 19;
name: {a b b d a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 3
t: 0 5 9 15
i: 0
t: 0 5 9 15 16;
name: {a b b d b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 3
t: 0 5 9 15
i: 1
t: 0 5 9 15 17;
name: {a b b d c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 3
t: 0 5 9 15
i: 2
t: 0 5 9 15 18;
name: {a b b d d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 1
t: 0 5 9
i: 3
t: 0 5 9 15
i: 3
t: 0 5 9 15 19;
name: {a b c a a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 0
t: 0 5 10 12
i: 0
t: 0 5 10 12 16;
name: {a b c a b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 0
t: 0 5 10 12
i: 1
t: 0 5 10 12 17;
name: {a b c a c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 0
t: 0 5 10 12
i: 2
t: 0 5 10 12 18;
name: {a b c a d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 0
t: 0 5 10 12
i: 3
t: 0 5 10 12 19;
name: {a b c b a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 1
t: 0 5 10 13
i: 0
t: 0 5 10 13 16;
name: {a b c b b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 1
t: 0 5 10 13
i: 1
t: 0 5 10 13 17;
name: {a b c b c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 1
t: 0 5 10 13
i: 2
t: 0 5 10 13 18;
name: {a b c b d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 1
t: 0 5 10 13
i: 3
t: 0 5 10 13 19;
name: {a b c c a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 2
t: 0 5 10 14
i: 0
t: 0 5 10 14 16;
name: {a b c c b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 2
t: 0 5 10 14
i: 1
t: 0 5 10 14 17;
name: {a b c c c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 2
t: 0 5 10 14
i: 2
t: 0 5 10 14 18;
name: {a b c c d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 2
t: 0 5 10 14
i: 3
t: 0 5 10 14 19;
name: {a b c d a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 3
t: 0 5 10 15
i: 0
t: 0 5 10 15 16;
name: {a b c d b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 3
t: 0 5 10 15
i: 1
t: 0 5 10 15 17;
name: {a b c d c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 3
t: 0 5 10 15
i: 2
t: 0 5 10 15 18;
name: {a b c d d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 2
t: 0 5 10
i: 3
t: 0 5 10 15
i: 3
t: 0 5 10 15 19;
name: {a b d a a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 0
t: 0 5 11 12
i: 0
t: 0 5 11 12 16;
name: {a b d a b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 0
t: 0 5 11 12
i: 1
t: 0 5 11 12 17;
name: {a b d a c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 0
t: 0 5 11 12
i: 2
t: 0 5 11 12 18;
name: {a b d a d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 0
t: 0 5 11 12
i: 3
t: 0 5 11 12 19;
name: {a b d b a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 1
t: 0 5 11 13
i: 0
t: 0 5 11 13 16;
name: {a b d b b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 1
t: 0 5 11 13
i: 1
t: 0 5 11 13 17;
name: {a b d b c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 1
t: 0 5 11 13
i: 2
t: 0 5 11 13 18;
name: {a b d b d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 1
t: 0 5 11 13
i: 3
t: 0 5 11 13 19;
name: {a b d c a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 2
t: 0 5 11 14
i: 0
t: 0 5 11 14 16;
name: {a b d c b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 2
t: 0 5 11 14
i: 1
t: 0 5 11 14 17;
name: {a b d c c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 2
t: 0 5 11 14
i: 2
t: 0 5 11 14 18;
name: {a b d c d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 2
t: 0 5 11 14
i: 3
t: 0 5 11 14 19;
name: {a b d d a} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 3
t: 0 5 11 15
i: 0
t: 0 5 11 15 16;
name: {a b d d b} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 3
t: 0 5 11 15
i: 1
t: 0 5 11 15 17;
name: {a b d d c} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 3
t: 0 5 11 15
i: 2
t: 0 5 11 15 18;
name: {a b d d d} 5
i: 0
t: 0
i: 1
t: 0 5
i: 3
t: 0 5 11
i: 3
t: 0 5 11 15
i: 3
t: 0 5 11 15 19;
name: {a c a a a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 0
t: 0 6 8 12
i: 0
t: 0 6 8 12 16;
name: {a c a a b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 0
t: 0 6 8 12
i: 1
t: 0 6 8 12 17;
name: {a c a a c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 0
t: 0 6 8 12
i: 2
t: 0 6 8 12 18;
name: {a c a a d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 0
t: 0 6 8 12
i: 3
t: 0 6 8 12 19;
name: {a c a b a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 1
t: 0 6 8 13
i: 0
t: 0 6 8 13 16;
name: {a c a b b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 1
t: 0 6 8 13
i: 1
t: 0 6 8 13 17;
name: {a c a b c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 1
t: 0 6 8 13
i: 2
t: 0 6 8 13 18;
name: {a c a b d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 1
t: 0 6 8 13
i: 3
t: 0 6 8 13 19;
name: {a c a c a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 2
t: 0 6 8 14
i: 0
t: 0 6 8 14 16;
name: {a c a c b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 2
t: 0 6 8 14
i: 1
t: 0 6 8 14 17;
name: {a c a c c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 2
t: 0 6 8 14
i: 2
t: 0 6 8 14 18;
name: {a c a c d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 2
t: 0 6 8 14
i: 3
t: 0 6 8 14 19;
name: {a c a d a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 3
t: 0 6 8 15
i: 0
t: 0 6 8 15 16;
name: {a c a d b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 3
t: 0 6 8 15
i: 1
t: 0 6 8 15 17;
name: {a c a d c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 3
t: 0 6 8 15
i: 2
t: 0 6 8 15 18;
name: {a c a d d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 0
t: 0 6 8
i: 3
t: 0 6 8 15
i: 3
t: 0 6 8 15 19;
name: {a c b a a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 0
t: 0 6 9 12
i: 0
t: 0 6 9 12 16;
name: {a c b a b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 0
t: 0 6 9 12
i: 1
t: 0 6 9 12 17;
name: {a c b a c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 0
t: 0 6 9 12
i: 2
t: 0 6 9 12 18;
name: {a c b a d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 0
t: 0 6 9 12
i: 3
t: 0 6 9 12 19;
name: {a c b b a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 1
t: 0 6 9 13
i: 0
t: 0 6 9 13 16;
name: {a c b b b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 1
t: 0 6 9 13
i: 1
t: 0 6 9 13 17;
name: {a c b b c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 1
t: 0 6 9 13
i: 2
t: 0 6 9 13 18;
name: {a c b b d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 1
t: 0 6 9 13
i: 3
t: 0 6 9 13 19;
name: {a c b c a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 2
t: 0 6 9 14
i: 0
t: 0 6 9 14 16;
name: {a c b c b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 2
t: 0 6 9 14
i: 1
t: 0 6 9 14 17;
name: {a c b c c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 2
t: 0 6 9 14
i: 2
t: 0 6 9 14 18;
name: {a c b c d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 2
t: 0 6 9 14
i: 3
t: 0 6 9 14 19;
name: {a c b d a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 3
t: 0 6 9 15
i: 0
t: 0 6 9 15 16;
name: {a c b d b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 3
t: 0 6 9 15
i: 1
t: 0 6 9 15 17;
name: {a c b d c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 3
t: 0 6 9 15
i: 2
t: 0 6 9 15 18;
name: {a c b d d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 1
t: 0 6 9
i: 3
t: 0 6 9 15
i: 3
t: 0 6 9 15 19;
name: {a c c a a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 0
t: 0 6 10 12
i: 0
t: 0 6 10 12 16;
name: {a c c a b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 0
t: 0 6 10 12
i: 1
t: 0 6 10 12 17;
name: {a c c a c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 0
t: 0 6 10 12
i: 2
t: 0 6 10 12 18;
name: {a c c a d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 0
t: 0 6 10 12
i: 3
t: 0 6 10 12 19;
name: {a c c b a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 1
t: 0 6 10 13
i: 0
t: 0 6 10 13 16;
name: {a c c b b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 1
t: 0 6 10 13
i: 1
t: 0 6 10 13 17;
name: {a c c b c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 1
t: 0 6 10 13
i: 2
t: 0 6 10 13 18;
name: {a c c b d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 1
t: 0 6 10 13
i: 3
t: 0 6 10 13 19;
name: {a c c c a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 2
t: 0 6 10 14
i: 0
t: 0 6 10 14 16;
name: {a c c c b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 2
t: 0 6 10 14
i: 1
t: 0 6 10 14 17;
name: {a c c c c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 2
t: 0 6 10 14
i: 2
t: 0 6 10 14 18;
name: {a c c c d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 2
t: 0 6 10 14
i: 3
t: 0 6 10 14 19;
name: {a c c d a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 3
t: 0 6 10 15
i: 0
t: 0 6 10 15 16;
name: {a c c d b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 3
t: 0 6 10 15
i: 1
t: 0 6 10 15 17;
name: {a c c d c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 3
t: 0 6 10 15
i: 2
t: 0 6 10 15 18;
name: {a c c d d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 2
t: 0 6 10
i: 3
t: 0 6 10 15
i: 3
t: 0 6 10 15 19;
name: {a c d a a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 0
t: 0 6 11 12
i: 0
t: 0 6 11 12 16;
name: {a c d a b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 0
t: 0 6 11 12
i: 1
t: 0 6 11 12 17;
name: {a c d a c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 0
t: 0 6 11 12
i: 2
t: 0 6 11 12 18;
name: {a c d a d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 0
t: 0 6 11 12
i: 3
t: 0 6 11 12 19;
name: {a c d b a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 1
t: 0 6 11 13
i: 0
t: 0 6 11 13 16;
name: {a c d b b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 1
t: 0 6 11 13
i: 1
t: 0 6 11 13 17;
name: {a c d b c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 1
t: 0 6 11 13
i: 2
t: 0 6 11 13 18;
name: {a c d b d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 1
t: 0 6 11 13
i: 3
t: 0 6 11 13 19;
name: {a c d c a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 2
t: 0 6 11 14
i: 0
t: 0 6 11 14 16;
name: {a c d c b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 2
t: 0 6 11 14
i: 1
t: 0 6 11 14 17;
name: {a c d c c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 2
t: 0 6 11 14
i: 2
t: 0 6 11 14 18;
name: {a c d c d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 2
t: 0 6 11 14
i: 3
t: 0 6 11 14 19;
name: {a c d d a} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 3
t: 0 6 11 15
i: 0
t: 0 6 11 15 16;
name: {a c d d b} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 3
t: 0 6 11 15
i: 1
t: 0 6 11 15 17;
name: {a c d d c} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 3
t: 0 6 11 15
i: 2
t: 0 6 11 15 18;
name: {a c d d d} 5
i: 0
t: 0
i: 2
t: 0 6
i: 3
t: 0 6 11
i: 3
t: 0 6 11 15
i: 3
t: 0 6 11 15 19;
name: {a d a a a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 0
t: 0 7 8 12
i: 0
t: 0 7 8 12 16;
name: {a d a a b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 0
t: 0 7 8 12
i: 1
t: 0 7 8 12 17;
name: {a d a a c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 0
t: 0 7 8 12
i: 2
t: 0 7 8 12 18;
name: {a d a a d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 0
t: 0 7 8 12
i: 3
t: 0 7 8 12 19;
name: {a d a b a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 1
t: 0 7 8 13
i: 0
t: 0 7 8 13 16;
name: {a d a b b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 1
t: 0 7 8 13
i: 1
t: 0 7 8 13 17;
name: {a d a b c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 1
t: 0 7 8 13
i: 2
t: 0 7 8 13 18;
name: {a d a b d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 1
t: 0 7 8 13
i: 3
t: 0 7 8 13 19;
name: {a d a c a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 2
t: 0 7 8 14
i: 0
t: 0 7 8 14 16;
name: {a d a c b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 2
t: 0 7 8 14
i: 1
t: 0 7 8 14 17;
name: {a d a c c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 2
t: 0 7 8 14
i: 2
t: 0 7 8 14 18;
name: {a d a c d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 2
t: 0 7 8 14
i: 3
t: 0 7 8 14 19;
name: {a d a d a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 3
t: 0 7 8 15
i: 0
t: 0 7 8 15 16;
name: {a d a d b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 3
t: 0 7 8 15
i: 1
t: 0 7 8 15 17;
name: {a d a d c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 3
t: 0 7 8 15
i: 2
t: 0 7 8 15 18;
name: {a d a d d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 0
t: 0 7 8
i: 3
t: 0 7 8 15
i: 3
t: 0 7 8 15 19;
name: {a d b a a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 0
t: 0 7 9 12
i: 0
t: 0 7 9 12 16;
name: {a d b a b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 0
t: 0 7 9 12
i: 1
t: 0 7 9 12 17;
name: {a d b a c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 0
t: 0 7 9 12
i: 2
t: 0 7 9 12 18;
name: {a d b a d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 0
t: 0 7 9 12
i: 3
t: 0 7 9 12 19;
name: {a d b b a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 1
t: 0 7 9 13
i: 0
t: 0 7 9 13 16;
name: {a d b b b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 1
t: 0 7 9 13
i: 1
t: 0 7 9 13 17;
name: {a d b b c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 1
t: 0 7 9 13
i: 2
t: 0 7 9 13 18;
name: {a d b b d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 1
t: 0 7 9 13
i: 3
t: 0 7 9 13 19;
name: {a d b c a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 2
t: 0 7 9 14
i: 0
t: 0 7 9 14 16;
name: {a d b c b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 2
t: 0 7 9 14
i: 1
t: 0 7 9 14 17;
name: {a d b c c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 2
t: 0 7 9 14
i: 2
t: 0 7 9 14 18;
name: {a d b c d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 2
t: 0 7 9 14
i: 3
t: 0 7 9 14 19;
name: {a d b d a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 3
t: 0 7 9 15
i: 0
t: 0 7 9 15 16;
name: {a d b d b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 3
t: 0 7 9 15
i: 1
t: 0 7 9 15 17;
name: {a d b d c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 3
t: 0 7 9 15
i: 2
t: 0 7 9 15 18;
name: {a d b d d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 1
t: 0 7 9
i: 3
t: 0 7 9 15
i: 3
t: 0 7 9 15 19;
name: {a d c a a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 0
t: 0 7 10 12
i: 0
t: 0 7 10 12 16;
name: {a d c a b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 0
t: 0 7 10 12
i: 1
t: 0 7 10 12 17;
name: {a d c a c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 0
t: 0 7 10 12
i: 2
t: 0 7 10 12 18;
name: {a d c a d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 0
t: 0 7 10 12
i: 3
t: 0 7 10 12 19;
name: {a d c b a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 1
t: 0 7 10 13
i: 0
t: 0 7 10 13 16;
name: {a d c b b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 1
t: 0 7 10 13
i: 1
t: 0 7 10 13 17;
name: {a d c b c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 1
t: 0 7 10 13
i: 2
t: 0 7 10 13 18;
name: {a d c b d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 1
t: 0 7 10 13
i: 3
t: 0 7 10 13 19;
name: {a d c c a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 2
t: 0 7 10 14
i: 0
t: 0 7 10 14 16;
name: {a d c c b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 2
t: 0 7 10 14
i: 1
t: 0 7 10 14 17;
name: {a d c c c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 2
t: 0 7 10 14
i: 2
t: 0 7 10 14 18;
name: {a d c c d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 2
t: 0 7 10 14
i: 3
t: 0 7 10 14 19;
name: {a d c d a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 3
t: 0 7 10 15
i: 0
t: 0 7 10 15 16;
name: {a d c d b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 3
t: 0 7 10 15
i: 1
t: 0 7 10 15 17;
name: {a d c d c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 3
t: 0 7 10 15
i: 2
t: 0 7 10 15 18;
name: {a d c d d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 2
t: 0 7 10
i: 3
t: 0 7 10 15
i: 3
t: 0 7 10 15 19;
name: {a d d a a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 0
t: 0 7 11 12
i: 0
t: 0 7 11 12 16;
name: {a d d a b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 0
t: 0 7 11 12
i: 1
t: 0 7 11 12 17;
name: {a d d a c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 0
t: 0 7 11 12
i: 2
t: 0 7 11 12 18;
name: {a d d a d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 0
t: 0 7 11 12
i: 3
t: 0 7 11 12 19;
name: {a d d b a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 1
t: 0 7 11 13
i: 0
t: 0 7 11 13 16;
name: {a d d b b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 1
t: 0 7 11 13
i: 1
t: 0 7 11 13 17;
name: {a d d b c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 1
t: 0 7 11 13
i: 2
t: 0 7 11 13 18;
name: {a d d b d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 1
t: 0 7 11 13
i: 3
t: 0 7 11 13 19;
name: {a d d c a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 2
t: 0 7 11 14
i: 0
t: 0 7 11 14 16;
name: {a d d c b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 2
t: 0 7 11 14
i: 1
t: 0 7 11 14 17;
name: {a d d c c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 2
t: 0 7 11 14
i: 2
t: 0 7 11 14 18;
name: {a d d c d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 2
t: 0 7 11 14
i: 3
t: 0 7 11 14 19;
name: {a d d d a} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 3
t: 0 7 11 15
i: 0
t: 0 7 11 15 16;
name: {a d d d b} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 3
t: 0 7 11 15
i: 1
t: 0 7 11 15 17;
name: {a d d d c} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 3
t: 0 7 11 15
i: 2
t: 0 7 11 15 18;
name: {a d d d d} 5
i: 0
t: 0
i: 3
t: 0 7
i: 3
t: 0 7 11
i: 3
t: 0 7 11 15
i: 3
t: 0 7 11 15 19;
name: {b a a a a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 0
t: 1 4 8 12
i: 0
t: 1 4 8 12 16;
name: {b a a a b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 0
t: 1 4 8 12
i: 1
t: 1 4 8 12 17;
name: {b a a a c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 0
t: 1 4 8 12
i: 2
t: 1 4 8 12 18;
name: {b a a a d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 0
t: 1 4 8 12
i: 3
t: 1 4 8 12 19;
name: {b a a b a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 1
t: 1 4 8 13
i: 0
t: 1 4 8 13 16;
name: {b a a b b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 1
t: 1 4 8 13
i: 1
t: 1 4 8 13 17;
name: {b a a b c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 1
t: 1 4 8 13
i: 2
t: 1 4 8 13 18;
name: {b a a b d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 1
t: 1 4 8 13
i: 3
t: 1 4 8 13 19;
name: {b a a c a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 2
t: 1 4 8 14
i: 0
t: 1 4 8 14 16;
name: {b a a c b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 2
t: 1 4 8 14
i: 1
t: 1 4 8 14 17;
name: {b a a c c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 2
t: 1 4 8 14
i: 2
t: 1 4 8 14 18;
name: {b a a c d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 2
t: 1 4 8 14
i: 3
t: 1 4 8 14 19;
name: {b a a d a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 3
t: 1 4 8 15
i: 0
t: 1 4 8 15 16;
name: {b a a d b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 3
t: 1 4 8 15
i: 1
t: 1 4 8 15 17;
name: {b a a d c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 3
t: 1 4 8 15
i: 2
t: 1 4 8 15 18;
name: {b a a d d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 0
t: 1 4 8
i: 3
t: 1 4 8 15
i: 3
t: 1 4 8 15 19;
name: {b a b a a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 0
t: 1 4 9 12
i: 0
t: 1 4 9 12 16;
name: {b a b a b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 0
t: 1 4 9 12
i: 1
t: 1 4 9 12 17;
name: {b a b a c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 0
t: 1 4 9 12
i: 2
t: 1 4 9 12 18;
name: {b a b a d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 0
t: 1 4 9 12
i: 3
t: 1 4 9 12 19;
name: {b a b b a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 1
t: 1 4 9 13
i: 0
t: 1 4 9 13 16;
name: {b a b b b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 1
t: 1 4 9 13
i: 1
t: 1 4 9 13 17;
name: {b a b b c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 1
t: 1 4 9 13
i: 2
t: 1 4 9 13 18;
name: {b a b b d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 1
t: 1 4 9 13
i: 3
t: 1 4 9 13 19;
name: {b a b c a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 2
t: 1 4 9 14
i: 0
t: 1 4 9 14 16;
name: {b a b c b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 2
t: 1 4 9 14
i: 1
t: 1 4 9 14 17;
name: {b a b c c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 2
t: 1 4 9 14
i: 2
t: 1 4 9 14 18;
name: {b a b c d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 2
t: 1 4 9 14
i: 3
t: 1 4 9 14 19;
name: {b a b d a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 3
t: 1 4 9 15
i: 0
t: 1 4 9 15 16;
name: {b a b d b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 3
t: 1 4 9 15
i: 1
t: 1 4 9 15 17;
name: {b a b d c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 3
t: 1 4 9 15
i: 2
t: 1 4 9 15 18;
name: {b a b d d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 1
t: 1 4 9
i: 3
t: 1 4 9 15
i: 3
t: 1 4 9 15 19;
name: {b a c a a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 0
t: 1 4 10 12
i: 0
t: 1 4 10 12 16;
name: {b a c a b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 0
t: 1 4 10 12
i: 1
t: 1 4 10 12 17;
name: {b a c a c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 0
t: 1 4 10 12
i: 2
t: 1 4 10 12 18;
name: {b a c a d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 0
t: 1 4 10 12
i: 3
t: 1 4 10 12 19;
name: {b a c b a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 1
t: 1 4 10 13
i: 0
t: 1 4 10 13 16;
name: {b a c b b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 1
t: 1 4 10 13
i: 1
t: 1 4 10 13 17;
name: {b a c b c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 1
t: 1 4 10 13
i: 2
t: 1 4 10 13 18;
name: {b a c b d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 1
t: 1 4 10 13
i: 3
t: 1 4 10 13 19;
name: {b a c c a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 2
t: 1 4 10 14
i: 0
t: 1 4 10 14 16;
name: {b a c c b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 2
t: 1 4 10 14
i: 1
t: 1 4 10 14 17;
name: {b a c c c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 2
t: 1 4 10 14
i: 2
t: 1 4 10 14 18;
name: {b a c c d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 2
t: 1 4 10 14
i: 3
t: 1 4 10 14 19;
name: {b a c d a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 3
t: 1 4 10 15
i: 0
t: 1 4 10 15 16;
name: {b a c d b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 3
t: 1 4 10 15
i: 1
t: 1 4 10 15 17;
name: {b a c d c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 3
t: 1 4 10 15
i: 2
t: 1 4 10 15 18;
name: {b a c d d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 2
t: 1 4 10
i: 3
t: 1 4 10 15
i: 3
t: 1 4 10 15 19;
name: {b a d a a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 0
t: 1 4 11 12
i: 0
t: 1 4 11 12 16;
name: {b a d a b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 0
t: 1 4 11 12
i: 1
t: 1 4 11 12 17;
name: {b a d a c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 0
t: 1 4 11 12
i: 2
t: 1 4 11 12 18;
name: {b a d a d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 0
t: 1 4 11 12
i: 3
t: 1 4 11 12 19;
name: {b a d b a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 1
t: 1 4 11 13
i: 0
t: 1 4 11 13 16;
name: {b a d b b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 1
t: 1 4 11 13
i: 1
t: 1 4 11 13 17;
name: {b a d b c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 1
t: 1 4 11 13
i: 2
t: 1 4 11 13 18;
name: {b a d b d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 1
t: 1 4 11 13
i: 3
t: 1 4 11 13 19;
name: {b a d c a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 2
t: 1 4 11 14
i: 0
t: 1 4 11 14 16;
name: {b a d c b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 2
t: 1 4 11 14
i: 1
t: 1 4 11 14 17;
name: {b a d c c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 2
t: 1 4 11 14
i: 2
t: 1 4 11 14 18;
name: {b a d c d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 2
t: 1 4 11 14
i: 3
t: 1 4 11 14 19;
name: {b a d d a} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 3
t: 1 4 11 15
i: 0
t: 1 4 11 15 16;
name: {b a d d b} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 3
t: 1 4 11 15
i: 1
t: 1 4 11 15 17;
name: {b a d d c} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 3
t: 1 4 11 15
i: 2
t: 1 4 11 15 18;
name: {b a d d d} 5
i: 1
t: 1
i: 0
t: 1 4
i: 3
t: 1 4 11
i: 3
t: 1 4 11 15
i: 3
t: 1 4 11 15 19;
name: {b b a a a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 0
t: 1 5 8 12
i: 0
t: 1 5 8 12 16;
name: {b b a a b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 0
t: 1 5 8 12
i: 1
t: 1 5 8 12 17;
name: {b b a a c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 0
t: 1 5 8 12
i: 2
t: 1 5 8 12 18;
name: {b b a a d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 0
t: 1 5 8 12
i: 3
t: 1 5 8 12 19;
name: {b b a b a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 1
t: 1 5 8 13
i: 0
t: 1 5 8 13 16;
name: {b b a b b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 1
t: 1 5 8 13
i: 1
t: 1 5 8 13 17;
name: {b b a b c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 1
t: 1 5 8 13
i: 2
t: 1 5 8 13 18;
name: {b b a b d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 1
t: 1 5 8 13
i: 3
t: 1 5 8 13 19;
name: {b b a c a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 2
t: 1 5 8 14
i: 0
t: 1 5 8 14 16;
name: {b b a c b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 2
t: 1 5 8 14
i: 1
t: 1 5 8 14 17;
name: {b b a c c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 2
t: 1 5 8 14
i: 2
t: 1 5 8 14 18;
name: {b b a c d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 2
t: 1 5 8 14
i: 3
t: 1 5 8 14 19;
name: {b b a d a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 3
t: 1 5 8 15
i: 0
t: 1 5 8 15 16;
name: {b b a d b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 3
t: 1 5 8 15
i: 1
t: 1 5 8 15 17;
name: {b b a d c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 3
t: 1 5 8 15
i: 2
t: 1 5 8 15 18;
name: {b b a d d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 0
t: 1 5 8
i: 3
t: 1 5 8 15
i: 3
t: 1 5 8 15 19;
name: {b b b a a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 0
t: 1 5 9 12
i: 0
t: 1 5 9 12 16;
name: {b b b a b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 0
t: 1 5 9 12
i: 1
t: 1 5 9 12 17;
name: {b b b a c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 0
t: 1 5 9 12
i: 2
t: 1 5 9 12 18;
name: {b b b a d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 0
t: 1 5 9 12
i: 3
t: 1 5 9 12 19;
name: {b b b b a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 1
t: 1 5 9 13
i: 0
t: 1 5 9 13 16;
name: {b b b b b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 1
t: 1 5 9 13
i: 1
t: 1 5 9 13 17;
name: {b b b b c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 1
t: 1 5 9 13
i: 2
t: 1 5 9 13 18;
name: {b b b b d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 1
t: 1 5 9 13
i: 3
t: 1 5 9 13 19;
name: {b b b c a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 2
t: 1 5 9 14
i: 0
t: 1 5 9 14 16;
name: {b b b c b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 2
t: 1 5 9 14
i: 1
t: 1 5 9 14 17;
name: {b b b c c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 2
t: 1 5 9 14
i: 2
t: 1 5 9 14 18;
name: {b b b c d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 2
t: 1 5 9 14
i: 3
t: 1 5 9 14 19;
name: {b b b d a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 3
t: 1 5 9 15
i: 0
t: 1 5 9 15 16;
name: {b b b d b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 3
t: 1 5 9 15
i: 1
t: 1 5 9 15 17;
name: {b b b d c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 3
t: 1 5 9 15
i: 2
t: 1 5 9 15 18;
name: {b b b d d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 1
t: 1 5 9
i: 3
t: 1 5 9 15
i: 3
t: 1 5 9 15 19;
name: {b b c a a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 0
t: 1 5 10 12
i: 0
t: 1 5 10 12 16;
name: {b b c a b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 0
t: 1 5 10 12
i: 1
t: 1 5 10 12 17;
name: {b b c a c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 0
t: 1 5 10 12
i: 2
t: 1 5 10 12 18;
name: {b b c a d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 0
t: 1 5 10 12
i: 3
t: 1 5 10 12 19;
name: {b b c b a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 1
t: 1 5 10 13
i: 0
t: 1 5 10 13 16;
name: {b b c b b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 1
t: 1 5 10 13
i: 1
t: 1 5 10 13 17;
name: {b b c b c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 1
t: 1 5 10 13
i: 2
t: 1 5 10 13 18;
name: {b b c b d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 1
t: 1 5 10 13
i: 3
t: 1 5 10 13 19;
name: {b b c c a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 2
t: 1 5 10 14
i: 0
t: 1 5 10 14 16;
name: {b b c c b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 2
t: 1 5 10 14
i: 1
t: 1 5 10 14 17;
name: {b b c c c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 2
t: 1 5 10 14
i: 2
t: 1 5 10 14 18;
name: {b b c c d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 2
t: 1 5 10 14
i: 3
t: 1 5 10 14 19;
name: {b b c d a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 3
t: 1 5 10 15
i: 0
t: 1 5 10 15 16;
name: {b b c d b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 3
t: 1 5 10 15
i: 1
t: 1 5 10 15 17;
name: {b b c d c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 3
t: 1 5 10 15
i: 2
t: 1 5 10 15 18;
name: {b b c d d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 2
t: 1 5 10
i: 3
t: 1 5 10 15
i: 3
t: 1 5 10 15 19;
name: {b b d a a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 0
t: 1 5 11 12
i: 0
t: 1 5 11 12 16;
name: {b b d a b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 0
t: 1 5 11 12
i: 1
t: 1 5 11 12 17;
name: {b b d a c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 0
t: 1 5 11 12
i: 2
t: 1 5 11 12 18;
name: {b b d a d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 0
t: 1 5 11 12
i: 3
t: 1 5 11 12 19;
name: {b b d b a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 1
t: 1 5 11 13
i: 0
t: 1 5 11 13 16;
name: {b b d b b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 1
t: 1 5 11 13
i: 1
t: 1 5 11 13 17;
name: {b b d b c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 1
t: 1 5 11 13
i: 2
t: 1 5 11 13 18;
name: {b b d b d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 1
t: 1 5 11 13
i: 3
t: 1 5 11 13 19;
name: {b b d c a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 2
t: 1 5 11 14
i: 0
t: 1 5 11 14 16;
name: {b b d c b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 2
t: 1 5 11 14
i: 1
t: 1 5 11 14 17;
name: {b b d c c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 2
t: 1 5 11 14
i: 2
t: 1 5 11 14 18;
name: {b b d c d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 2
t: 1 5 11 14
i: 3
t: 1 5 11 14 19;
name: {b b d d a} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 3
t: 1 5 11 15
i: 0
t: 1 5 11 15 16;
name: {b b d d b} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 3
t: 1 5 11 15
i: 1
t: 1 5 11 15 17;
name: {b b d d c} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 3
t: 1 5 11 15
i: 2
t: 1 5 11 15 18;
name: {b b d d d} 5
i: 1
t: 1
i: 1
t: 1 5
i: 3
t: 1 5 11
i: 3
t: 1 5 11 15
i: 3
t: 1 5 11 15 19;
name: {b c a a a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 0
t: 1 6 8 12
i: 0
t: 1 6 8 12 16;
name: {b c a a b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 0
t: 1 6 8 12
i: 1
t: 1 6 8 12 17;
name: {b c a a c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 0
t: 1 6 8 12
i: 2
t: 1 6 8 12 18;
name: {b c a a d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 0
t: 1 6 8 12
i: 3
t: 1 6 8 12 19;
name: {b c a b a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 1
t: 1 6 8 13
i: 0
t: 1 6 8 13 16;
name: {b c a b b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 1
t: 1 6 8 13
i: 1
t: 1 6 8 13 17;
name: {b c a b c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 1
t: 1 6 8 13
i: 2
t: 1 6 8 13 18;
name: {b c a b d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 1
t: 1 6 8 13
i: 3
t: 1 6 8 13 19;
name: {b c a c a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 2
t: 1 6 8 14
i: 0
t: 1 6 8 14 16;
name: {b c a c b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 2
t: 1 6 8 14
i: 1
t: 1 6 8 14 17;
name: {b c a c c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 2
t: 1 6 8 14
i: 2
t: 1 6 8 14 18;
name: {b c a c d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 2
t: 1 6 8 14
i: 3
t: 1 6 8 14 19;
name: {b c a d a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 3
t: 1 6 8 15
i: 0
t: 1 6 8 15 16;
name: {b c a d b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 3
t: 1 6 8 15
i: 1
t: 1 6 8 15 17;
name: {b c a d c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 3
t: 1 6 8 15
i: 2
t: 1 6 8 15 18;
name: {b c a d d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 0
t: 1 6 8
i: 3
t: 1 6 8 15
i: 3
t: 1 6 8 15 19;
name: {b c b a a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 0
t: 1 6 9 12
i: 0
t: 1 6 9 12 16;
name: {b c b a b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 0
t: 1 6 9 12
i: 1
t: 1 6 9 12 17;
name: {b c b a c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 0
t: 1 6 9 12
i: 2
t: 1 6 9 12 18;
name: {b c b a d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 0
t: 1 6 9 12
i: 3
t: 1 6 9 12 19;
name: {b c b b a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 1
t: 1 6 9 13
i: 0
t: 1 6 9 13 16;
name: {b c b b b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 1
t: 1 6 9 13
i: 1
t: 1 6 9 13 17;
name: {b c b b c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 1
t: 1 6 9 13
i: 2
t: 1 6 9 13 18;
name: {b c b b d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 1
t: 1 6 9 13
i: 3
t: 1 6 9 13 19;
name: {b c b c a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 2
t: 1 6 9 14
i: 0
t: 1 6 9 14 16;
name: {b c b c b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 2
t: 1 6 9 14
i: 1
t: 1 6 9 14 17;
name: {b c b c c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 2
t: 1 6 9 14
i: 2
t: 1 6 9 14 18;
name: {b c b c d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 2
t: 1 6 9 14
i: 3
t: 1 6 9 14 19;
name: {b c b d a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 3
t: 1 6 9 15
i: 0
t: 1 6 9 15 16;
name: {b c b d b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 3
t: 1 6 9 15
i: 1
t: 1 6 9 15 17;
name: {b c b d c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 3
t: 1 6 9 15
i: 2
t: 1 6 9 15 18;
name: {b c b d d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 1
t: 1 6 9
i: 3
t: 1 6 9 15
i: 3
t: 1 6 9 15 19;
name: {b c c a a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 0
t: 1 6 10 12
i: 0
t: 1 6 10 12 16;
name: {b c c a b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 0
t: 1 6 10 12
i: 1
t: 1 6 10 12 17;
name: {b c c a c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 0
t: 1 6 10 12
i: 2
t: 1 6 10 12 18;
name: {b c c a d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 0
t: 1 6 10 12
i: 3
t: 1 6 10 12 19;
name: {b c c b a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 1
t: 1 6 10 13
i: 0
t: 1 6 10 13 16;
name: {b c c b b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 1
t: 1 6 10 13
i: 1
t: 1 6 10 13 17;
name: {b c c b c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 1
t: 1 6 10 13
i: 2
t: 1 6 10 13 18;
name: {b c c b d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 1
t: 1 6 10 13
i: 3
t: 1 6 10 13 19;
name: {b c c c a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 2
t: 1 6 10 14
i: 0
t: 1 6 10 14 16;
name: {b c c c b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 2
t: 1 6 10 14
i: 1
t: 1 6 10 14 17;
name: {b c c c c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 2
t: 1 6 10 14
i: 2
t: 1 6 10 14 18;
name: {b c c c d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 2
t: 1 6 10 14
i: 3
t: 1 6 10 14 19;
name: {b c c d a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 3
t: 1 6 10 15
i: 0
t: 1 6 10 15 16;
name: {b c c d b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 3
t: 1 6 10 15
i: 1
t: 1 6 10 15 17;
name: {b c c d c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 3
t: 1 6 10 15
i: 2
t: 1 6 10 15 18;
name: {b c c d d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 2
t: 1 6 10
i: 3
t: 1 6 10 15
i: 3
t: 1 6 10 15 19;
name: {b c d a a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 0
t: 1 6 11 12
i: 0
t: 1 6 11 12 16;
name: {b c d a b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 0
t: 1 6 11 12
i: 1
t: 1 6 11 12 17;
name: {b c d a c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 0
t: 1 6 11 12
i: 2
t: 1 6 11 12 18;
name: {b c d a d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 0
t: 1 6 11 12
i: 3
t: 1 6 11 12 19;
name: {b c d b a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 1
t: 1 6 11 13
i: 0
t: 1 6 11 13 16;
name: {b c d b b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 1
t: 1 6 11 13
i: 1
t: 1 6 11 13 17;
name: {b c d b c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 1
t: 1 6 11 13
i: 2
t: 1 6 11 13 18;
name: {b c d b d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 1
t: 1 6 11 13
i: 3
t: 1 6 11 13 19;
name: {b c d c a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 2
t: 1 6 11 14
i: 0
t: 1 6 11 14 16;
name: {b c d c b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 2
t: 1 6 11 14
i: 1
t: 1 6 11 14 17;
name: {b c d c c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 2
t: 1 6 11 14
i: 2
t: 1 6 11 14 18;
name: {b c d c d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 2
t: 1 6 11 14
i: 3
t: 1 6 11 14 19;
name: {b c d d a} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 3
t: 1 6 11 15
i: 0
t: 1 6 11 15 16;
name: {b c d d b} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 3
t: 1 6 11 15
i: 1
t: 1 6 11 15 17;
name: {b c d d c} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 3
t: 1 6 11 15
i: 2
t: 1 6 11 15 18;
name: {b c d d d} 5
i: 1
t: 1
i: 2
t: 1 6
i: 3
t: 1 6 11
i: 3
t: 1 6 11 15
i: 3
t: 1 6 11 15 19;
name: {b d a a a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 0
t: 1 7 8 12
i: 0
t: 1 7 8 12 16;
name: {b d a a b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 0
t: 1 7 8 12
i: 1
t: 1 7 8 12 17;
name: {b d a a c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 0
t: 1 7 8 12
i: 2
t: 1 7 8 12 18;
name: {b d a a d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 0
t: 1 7 8 12
i: 3
t: 1 7 8 12 19;
name: {b d a b a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 1
t: 1 7 8 13
i: 0
t: 1 7 8 13 16;
name: {b d a b b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 1
t: 1 7 8 13
i: 1
t: 1 7 8 13 17;
name: {b d a b c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 1
t: 1 7 8 13
i: 2
t: 1 7 8 13 18;
name: {b d a b d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 1
t: 1 7 8 13
i: 3
t: 1 7 8 13 19;
name: {b d a c a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 2
t: 1 7 8 14
i: 0
t: 1 7 8 14 16;
name: {b d a c b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 2
t: 1 7 8 14
i: 1
t: 1 7 8 14 17;
name: {b d a c c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 2
t: 1 7 8 14
i: 2
t: 1 7 8 14 18;
name: {b d a c d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 2
t: 1 7 8 14
i: 3
t: 1 7 8 14 19;
name: {b d a d a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 3
t: 1 7 8 15
i: 0
t: 1 7 8 15 16;
name: {b d a d b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 3
t: 1 7 8 15
i: 1
t: 1 7 8 15 17;
name: {b d a d c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 3
t: 1 7 8 15
i: 2
t: 1 7 8 15 18;
name: {b d a d d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 0
t: 1 7 8
i: 3
t: 1 7 8 15
i: 3
t: 1 7 8 15 19;
name: {b d b a a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 0
t: 1 7 9 12
i: 0
t: 1 7 9 12 16;
name: {b d b a b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 0
t: 1 7 9 12
i: 1
t: 1 7 9 12 17;
name: {b d b a c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 0
t: 1 7 9 12
i: 2
t: 1 7 9 12 18;
name: {b d b a d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 0
t: 1 7 9 12
i: 3
t: 1 7 9 12 19;
name: {b d b b a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 1
t: 1 7 9 13
i: 0
t: 1 7 9 13 16;
name: {b d b b b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 1
t: 1 7 9 13
i: 1
t: 1 7 9 13 17;
name: {b d b b c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 1
t: 1 7 9 13
i: 2
t: 1 7 9 13 18;
name: {b d b b d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 1
t: 1 7 9 13
i: 3
t: 1 7 9 13 19;
name: {b d b c a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 2
t: 1 7 9 14
i: 0
t: 1 7 9 14 16;
name: {b d b c b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 2
t: 1 7 9 14
i: 1
t: 1 7 9 14 17;
name: {b d b c c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 2
t: 1 7 9 14
i: 2
t: 1 7 9 14 18;
name: {b d b c d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 2
t: 1 7 9 14
i: 3
t: 1 7 9 14 19;
name: {b d b d a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 3
t: 1 7 9 15
i: 0
t: 1 7 9 15 16;
name: {b d b d b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 3
t: 1 7 9 15
i: 1
t: 1 7 9 15 17;
name: {b d b d c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 3
t: 1 7 9 15
i: 2
t: 1 7 9 15 18;
name: {b d b d d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 1
t: 1 7 9
i: 3
t: 1 7 9 15
i: 3
t: 1 7 9 15 19;
name: {b d c a a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 0
t: 1 7 10 12
i: 0
t: 1 7 10 12 16;
name: {b d c a b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 0
t: 1 7 10 12
i: 1
t: 1 7 10 12 17;
name: {b d c a c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 0
t: 1 7 10 12
i: 2
t: 1 7 10 12 18;
name: {b d c a d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 0
t: 1 7 10 12
i: 3
t: 1 7 10 12 19;
name: {b d c b a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 1
t: 1 7 10 13
i: 0
t: 1 7 10 13 16;
name: {b d c b b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 1
t: 1 7 10 13
i: 1
t: 1 7 10 13 17;
name: {b d c b c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 1
t: 1 7 10 13
i: 2
t: 1 7 10 13 18;
name: {b d c b d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 1
t: 1 7 10 13
i: 3
t: 1 7 10 13 19;
name: {b d c c a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 2
t: 1 7 10 14
i: 0
t: 1 7 10 14 16;
name: {b d c c b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 2
t: 1 7 10 14
i: 1
t: 1 7 10 14 17;
name: {b d c c c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 2
t: 1 7 10 14
i: 2
t: 1 7 10 14 18;
name: {b d c c d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 2
t: 1 7 10 14
i: 3
t: 1 7 10 14 19;
name: {b d c d a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 3
t: 1 7 10 15
i: 0
t: 1 7 10 15 16;
name: {b d c d b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 3
t: 1 7 10 15
i: 1
t: 1 7 10 15 17;
name: {b d c d c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 3
t: 1 7 10 15
i: 2
t: 1 7 10 15 18;
name: {b d c d d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 2
t: 1 7 10
i: 3
t: 1 7 10 15
i: 3
t: 1 7 10 15 19;
name: {b d d a a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 0
t: 1 7 11 12
i: 0
t: 1 7 11 12 16;
name: {b d d a b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 0
t: 1 7 11 12
i: 1
t: 1 7 11 12 17;
name: {b d d a c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 0
t: 1 7 11 12
i: 2
t: 1 7 11 12 18;
name: {b d d a d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 0
t: 1 7 11 12
i: 3
t: 1 7 11 12 19;
name: {b d d b a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 1
t: 1 7 11 13
i: 0
t: 1 7 11 13 16;
name: {b d d b b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 1
t: 1 7 11 13
i: 1
t: 1 7 11 13 17;
name: {b d d b c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 1
t: 1 7 11 13
i: 2
t: 1 7 11 13 18;
name: {b d d b d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 1
t: 1 7 11 13
i: 3
t: 1 7 11 13 19;
name: {b d d c a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 2
t: 1 7 11 14
i: 0
t: 1 7 11 14 16;
name: {b d d c b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 2
t: 1 7 11 14
i: 1
t: 1 7 11 14 17;
name: {b d d c c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 2
t: 1 7 11 14
i: 2
t: 1 7 11 14 18;
name: {b d d c d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 2
t: 1 7 11 14
i: 3
t: 1 7 11 14 19;
name: {b d d d a} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 3
t: 1 7 11 15
i: 0
t: 1 7 11 15 16;
name: {b d d d b} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 3
t: 1 7 11 15
i: 1
t: 1 7 11 15 17;
name: {b d d d c} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 3
t: 1 7 11 15
i: 2
t: 1 7 11 15 18;
name: {b d d d d} 5
i: 1
t: 1
i: 3
t: 1 7
i: 3
t: 1 7 11
i: 3
t: 1 7 11 15
i: 3
t: 1 7 11 15 19;
name: {c a a a a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 0
t: 2 4 8 12
i: 0
t: 2 4 8 12 16;
name: {c a a a b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 0
t: 2 4 8 12
i: 1
t: 2 4 8 12 17;
name: {c a a a c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 0
t: 2 4 8 12
i: 2
t: 2 4 8 12 18;
name: {c a a a d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 0
t: 2 4 8 12
i: 3
t: 2 4 8 12 19;
name: {c a a b a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 1
t: 2 4 8 13
i: 0
t: 2 4 8 13 16;
name: {c a a b b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 1
t: 2 4 8 13
i: 1
t: 2 4 8 13 17;
name: {c a a b c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 1
t: 2 4 8 13
i: 2
t: 2 4 8 13 18;
name: {c a a b d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 1
t: 2 4 8 13
i: 3
t: 2 4 8 13 19;
name: {c a a c a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 2
t: 2 4 8 14
i: 0
t: 2 4 8 14 16;
name: {c a a c b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 2
t: 2 4 8 14
i: 1
t: 2 4 8 14 17;
name: {c a a c c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 2
t: 2 4 8 14
i: 2
t: 2 4 8 14 18;
name: {c a a c d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 2
t: 2 4 8 14
i: 3
t: 2 4 8 14 19;
name: {c a a d a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 3
t: 2 4 8 15
i: 0
t: 2 4 8 15 16;
name: {c a a d b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 3
t: 2 4 8 15
i: 1
t: 2 4 8 15 17;
name: {c a a d c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 3
t: 2 4 8 15
i: 2
t: 2 4 8 15 18;
name: {c a a d d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 0
t: 2 4 8
i: 3
t: 2 4 8 15
i: 3
t: 2 4 8 15 19;
name: {c a b a a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 0
t: 2 4 9 12
i: 0
t: 2 4 9 12 16;
name: {c a b a b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 0
t: 2 4 9 12
i: 1
t: 2 4 9 12 17;
name: {c a b a c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 0
t: 2 4 9 12
i: 2
t: 2 4 9 12 18;
name: {c a b a d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 0
t: 2 4 9 12
i: 3
t: 2 4 9 12 19;
name: {c a b b a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 1
t: 2 4 9 13
i: 0
t: 2 4 9 13 16;
name: {c a b b b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 1
t: 2 4 9 13
i: 1
t: 2 4 9 13 17;
name: {c a b b c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 1
t: 2 4 9 13
i: 2
t: 2 4 9 13 18;
name: {c a b b d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 1
t: 2 4 9 13
i: 3
t: 2 4 9 13 19;
name: {c a b c a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 2
t: 2 4 9 14
i: 0
t: 2 4 9 14 16;
name: {c a b c b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 2
t: 2 4 9 14
i: 1
t: 2 4 9 14 17;
name: {c a b c c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 2
t: 2 4 9 14
i: 2
t: 2 4 9 14 18;
name: {c a b c d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 2
t: 2 4 9 14
i: 3
t: 2 4 9 14 19;
name: {c a b d a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 3
t: 2 4 9 15
i: 0
t: 2 4 9 15 16;
name: {c a b d b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 3
t: 2 4 9 15
i: 1
t: 2 4 9 15 17;
name: {c a b d c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 3
t: 2 4 9 15
i: 2
t: 2 4 9 15 18;
name: {c a b d d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 1
t: 2 4 9
i: 3
t: 2 4 9 15
i: 3
t: 2 4 9 15 19;
name: {c a c a a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 0
t: 2 4 10 12
i: 0
t: 2 4 10 12 16;
name: {c a c a b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 0
t: 2 4 10 12
i: 1
t: 2 4 10 12 17;
name: {c a c a c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 0
t: 2 4 10 12
i: 2
t: 2 4 10 12 18;
name: {c a c a d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 0
t: 2 4 10 12
i: 3
t: 2 4 10 12 19;
name: {c a c b a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 1
t: 2 4 10 13
i: 0
t: 2 4 10 13 16;
name: {c a c b b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 1
t: 2 4 10 13
i: 1
t: 2 4 10 13 17;
name: {c a c b c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 1
t: 2 4 10 13
i: 2
t: 2 4 10 13 18;
name: {c a c b d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 1
t: 2 4 10 13
i: 3
t: 2 4 10 13 19;
name: {c a c c a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 2
t: 2 4 10 14
i: 0
t: 2 4 10 14 16;
name: {c a c c b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 2
t: 2 4 10 14
i: 1
t: 2 4 10 14 17;
name: {c a c c c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 2
t: 2 4 10 14
i: 2
t: 2 4 10 14 18;
name: {c a c c d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 2
t: 2 4 10 14
i: 3
t: 2 4 10 14 19;
name: {c a c d a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 3
t: 2 4 10 15
i: 0
t: 2 4 10 15 16;
name: {c a c d b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 3
t: 2 4 10 15
i: 1
t: 2 4 10 15 17;
name: {c a c d c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 3
t: 2 4 10 15
i: 2
t: 2 4 10 15 18;
name: {c a c d d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 2
t: 2 4 10
i: 3
t: 2 4 10 15
i: 3
t: 2 4 10 15 19;
name: {c a d a a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 0
t: 2 4 11 12
i: 0
t: 2 4 11 12 16;
name: {c a d a b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 0
t: 2 4 11 12
i: 1
t: 2 4 11 12 17;
name: {c a d a c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 0
t: 2 4 11 12
i: 2
t: 2 4 11 12 18;
name: {c a d a d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 0
t: 2 4 11 12
i: 3
t: 2 4 11 12 19;
name: {c a d b a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 1
t: 2 4 11 13
i: 0
t: 2 4 11 13 16;
name: {c a d b b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 1
t: 2 4 11 13
i: 1
t: 2 4 11 13 17;
name: {c a d b c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 1
t: 2 4 11 13
i: 2
t: 2 4 11 13 18;
name: {c a d b d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 1
t: 2 4 11 13
i: 3
t: 2 4 11 13 19;
name: {c a d c a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 2
t: 2 4 11 14
i: 0
t: 2 4 11 14 16;
name: {c a d c b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 2
t: 2 4 11 14
i: 1
t: 2 4 11 14 17;
name: {c a d c c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 2
t: 2 4 11 14
i: 2
t: 2 4 11 14 18;
name: {c a d c d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 2
t: 2 4 11 14
i: 3
t: 2 4 11 14 19;
name: {c a d d a} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 3
t: 2 4 11 15
i: 0
t: 2 4 11 15 16;
name: {c a d d b} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 3
t: 2 4 11 15
i: 1
t: 2 4 11 15 17;
name: {c a d d c} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 3
t: 2 4 11 15
i: 2
t: 2 4 11 15 18;
name: {c a d d d} 5
i: 2
t: 2
i: 0
t: 2 4
i: 3
t: 2 4 11
i: 3
t: 2 4 11 15
i: 3
t: 2 4 11 15 19;
name: {c b a a a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 0
t: 2 5 8 12
i: 0
t: 2 5 8 12 16;
name: {c b a a b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 0
t: 2 5 8 12
i: 1
t: 2 5 8 12 17;
name: {c b a a c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 0
t: 2 5 8 12
i: 2
t: 2 5 8 12 18;
name: {c b a a d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 0
t: 2 5 8 12
i: 3
t: 2 5 8 12 19;
name: {c b a b a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 1
t: 2 5 8 13
i: 0
t: 2 5 8 13 16;
name: {c b a b b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 1
t: 2 5 8 13
i: 1
t: 2 5 8 13 17;
name: {c b a b c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 1
t: 2 5 8 13
i: 2
t: 2 5 8 13 18;
name: {c b a b d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 1
t: 2 5 8 13
i: 3
t: 2 5 8 13 19;
name: {c b a c a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 2
t: 2 5 8 14
i: 0
t: 2 5 8 14 16;
name: {c b a c b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 2
t: 2 5 8 14
i: 1
t: 2 5 8 14 17;
name: {c b a c c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 2
t: 2 5 8 14
i: 2
t: 2 5 8 14 18;
name: {c b a c d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 2
t: 2 5 8 14
i: 3
t: 2 5 8 14 19;
name: {c b a d a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 3
t: 2 5 8 15
i: 0
t: 2 5 8 15 16;
name: {c b a d b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 3
t: 2 5 8 15
i: 1
t: 2 5 8 15 17;
name: {c b a d c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 3
t: 2 5 8 15
i: 2
t: 2 5 8 15 18;
name: {c b a d d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 0
t: 2 5 8
i: 3
t: 2 5 8 15
i: 3
t: 2 5 8 15 19;
name: {c b b a a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 0
t: 2 5 9 12
i: 0
t: 2 5 9 12 16;
name: {c b b a b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 0
t: 2 5 9 12
i: 1
t: 2 5 9 12 17;
name: {c b b a c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 0
t: 2 5 9 12
i: 2
t: 2 5 9 12 18;
name: {c b b a d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 0
t: 2 5 9 12
i: 3
t: 2 5 9 12 19;
name: {c b b b a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 1
t: 2 5 9 13
i: 0
t: 2 5 9 13 16;
name: {c b b b b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 1
t: 2 5 9 13
i: 1
t: 2 5 9 13 17;
name: {c b b b c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 1
t: 2 5 9 13
i: 2
t: 2 5 9 13 18;
name: {c b b b d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 1
t: 2 5 9 13
i: 3
t: 2 5 9 13 19;
name: {c b b c a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 2
t: 2 5 9 14
i: 0
t: 2 5 9 14 16;
name: {c b b c b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 2
t: 2 5 9 14
i: 1
t: 2 5 9 14 17;
name: {c b b c c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 2
t: 2 5 9 14
i: 2
t: 2 5 9 14 18;
name: {c b b c d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 2
t: 2 5 9 14
i: 3
t: 2 5 9 14 19;
name: {c b b d a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 3
t: 2 5 9 15
i: 0
t: 2 5 9 15 16;
name: {c b b d b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 3
t: 2 5 9 15
i: 1
t: 2 5 9 15 17;
name: {c b b d c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 3
t: 2 5 9 15
i: 2
t: 2 5 9 15 18;
name: {c b b d d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 1
t: 2 5 9
i: 3
t: 2 5 9 15
i: 3
t: 2 5 9 15 19;
name: {c b c a a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 0
t: 2 5 10 12
i: 0
t: 2 5 10 12 16;
name: {c b c a b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 0
t: 2 5 10 12
i: 1
t: 2 5 10 12 17;
name: {c b c a c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 0
t: 2 5 10 12
i: 2
t: 2 5 10 12 18;
name: {c b c a d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 0
t: 2 5 10 12
i: 3
t: 2 5 10 12 19;
name: {c b c b a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 1
t: 2 5 10 13
i: 0
t: 2 5 10 13 16;
name: {c b c b b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 1
t: 2 5 10 13
i: 1
t: 2 5 10 13 17;
name: {c b c b c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 1
t: 2 5 10 13
i: 2
t: 2 5 10 13 18;
name: {c b c b d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 1
t: 2 5 10 13
i: 3
t: 2 5 10 13 19;
name: {c b c c a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 2
t: 2 5 10 14
i: 0
t: 2 5 10 14 16;
name: {c b c c b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 2
t: 2 5 10 14
i: 1
t: 2 5 10 14 17;
name: {c b c c c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 2
t: 2 5 10 14
i: 2
t: 2 5 10 14 18;
name: {c b c c d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 2
t: 2 5 10 14
i: 3
t: 2 5 10 14 19;
name: {c b c d a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 3
t: 2 5 10 15
i: 0
t: 2 5 10 15 16;
name: {c b c d b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 3
t: 2 5 10 15
i: 1
t: 2 5 10 15 17;
name: {c b c d c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 3
t: 2 5 10 15
i: 2
t: 2 5 10 15 18;
name: {c b c d d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 2
t: 2 5 10
i: 3
t: 2 5 10 15
i: 3
t: 2 5 10 15 19;
name: {c b d a a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 0
t: 2 5 11 12
i: 0
t: 2 5 11 12 16;
name: {c b d a b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 0
t: 2 5 11 12
i: 1
t: 2 5 11 12 17;
name: {c b d a c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 0
t: 2 5 11 12
i: 2
t: 2 5 11 12 18;
name: {c b d a d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 0
t: 2 5 11 12
i: 3
t: 2 5 11 12 19;
name: {c b d b a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 1
t: 2 5 11 13
i: 0
t: 2 5 11 13 16;
name: {c b d b b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 1
t: 2 5 11 13
i: 1
t: 2 5 11 13 17;
name: {c b d b c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 1
t: 2 5 11 13
i: 2
t: 2 5 11 13 18;
name: {c b d b d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 1
t: 2 5 11 13
i: 3
t: 2 5 11 13 19;
name: {c b d c a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 2
t: 2 5 11 14
i: 0
t: 2 5 11 14 16;
name: {c b d c b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 2
t: 2 5 11 14
i: 1
t: 2 5 11 14 17;
name: {c b d c c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 2
t: 2 5 11 14
i: 2
t: 2 5 11 14 18;
name: {c b d c d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 2
t: 2 5 11 14
i: 3
t: 2 5 11 14 19;
name: {c b d d a} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 3
t: 2 5 11 15
i: 0
t: 2 5 11 15 16;
name: {c b d d b} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 3
t: 2 5 11 15
i: 1
t: 2 5 11 15 17;
name: {c b d d c} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 3
t: 2 5 11 15
i: 2
t: 2 5 11 15 18;
name: {c b d d d} 5
i: 2
t: 2
i: 1
t: 2 5
i: 3
t: 2 5 11
i: 3
t: 2 5 11 15
i: 3
t: 2 5 11 15 19;
name: {c c a a a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 0
t: 2 6 8 12
i: 0
t: 2 6 8 12 16;
name: {c c a a b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 0
t: 2 6 8 12
i: 1
t: 2 6 8 12 17;
name: {c c a a c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 0
t: 2 6 8 12
i: 2
t: 2 6 8 12 18;
name: {c c a a d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 0
t: 2 6 8 12
i: 3
t: 2 6 8 12 19;
name: {c c a b a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 1
t: 2 6 8 13
i: 0
t: 2 6 8 13 16;
name: {c c a b b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 1
t: 2 6 8 13
i: 1
t: 2 6 8 13 17;
name: {c c a b c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 1
t: 2 6 8 13
i: 2
t: 2 6 8 13 18;
name: {c c a b d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 1
t: 2 6 8 13
i: 3
t: 2 6 8 13 19;
name: {c c a c a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 2
t: 2 6 8 14
i: 0
t: 2 6 8 14 16;
name: {c c a c b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 2
t: 2 6 8 14
i: 1
t: 2 6 8 14 17;
name: {c c a c c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 2
t: 2 6 8 14
i: 2
t: 2 6 8 14 18;
name: {c c a c d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 2
t: 2 6 8 14
i: 3
t: 2 6 8 14 19;
name: {c c a d a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 3
t: 2 6 8 15
i: 0
t: 2 6 8 15 16;
name: {c c a d b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 3
t: 2 6 8 15
i: 1
t: 2 6 8 15 17;
name: {c c a d c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 3
t: 2 6 8 15
i: 2
t: 2 6 8 15 18;
name: {c c a d d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 0
t: 2 6 8
i: 3
t: 2 6 8 15
i: 3
t: 2 6 8 15 19;
name: {c c b a a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 0
t: 2 6 9 12
i: 0
t: 2 6 9 12 16;
name: {c c b a b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 0
t: 2 6 9 12
i: 1
t: 2 6 9 12 17;
name: {c c b a c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 0
t: 2 6 9 12
i: 2
t: 2 6 9 12 18;
name: {c c b a d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 0
t: 2 6 9 12
i: 3
t: 2 6 9 12 19;
name: {c c b b a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 1
t: 2 6 9 13
i: 0
t: 2 6 9 13 16;
name: {c c b b b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 1
t: 2 6 9 13
i: 1
t: 2 6 9 13 17;
name: {c c b b c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 1
t: 2 6 9 13
i: 2
t: 2 6 9 13 18;
name: {c c b b d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 1
t: 2 6 9 13
i: 3
t: 2 6 9 13 19;
name: {c c b c a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 2
t: 2 6 9 14
i: 0
t: 2 6 9 14 16;
name: {c c b c b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 2
t: 2 6 9 14
i: 1
t: 2 6 9 14 17;
name: {c c b c c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 2
t: 2 6 9 14
i: 2
t: 2 6 9 14 18;
name: {c c b c d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 2
t: 2 6 9 14
i: 3
t: 2 6 9 14 19;
name: {c c b d a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 3
t: 2 6 9 15
i: 0
t: 2 6 9 15 16;
name: {c c b d b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 3
t: 2 6 9 15
i: 1
t: 2 6 9 15 17;
name: {c c b d c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 3
t: 2 6 9 15
i: 2
t: 2 6 9 15 18;
name: {c c b d d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 1
t: 2 6 9
i: 3
t: 2 6 9 15
i: 3
t: 2 6 9 15 19;
name: {c c c a a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 0
t: 2 6 10 12
i: 0
t: 2 6 10 12 16;
name: {c c c a b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 0
t: 2 6 10 12
i: 1
t: 2 6 10 12 17;
name: {c c c a c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 0
t: 2 6 10 12
i: 2
t: 2 6 10 12 18;
name: {c c c a d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 0
t: 2 6 10 12
i: 3
t: 2 6 10 12 19;
name: {c c c b a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 1
t: 2 6 10 13
i: 0
t: 2 6 10 13 16;
name: {c c c b b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 1
t: 2 6 10 13
i: 1
t: 2 6 10 13 17;
name: {c c c b c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 1
t: 2 6 10 13
i: 2
t: 2 6 10 13 18;
name: {c c c b d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 1
t: 2 6 10 13
i: 3
t: 2 6 10 13 19;
name: {c c c c a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 2
t: 2 6 10 14
i: 0
t: 2 6 10 14 16;
name: {c c c c b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 2
t: 2 6 10 14
i: 1
t: 2 6 10 14 17;
name: {c c c c c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 2
t: 2 6 10 14
i: 2
t: 2 6 10 14 18;
name: {c c c c d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 2
t: 2 6 10 14
i: 3
t: 2 6 10 14 19;
name: {c c c d a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 3
t: 2 6 10 15
i: 0
t: 2 6 10 15 16;
name: {c c c d b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 3
t: 2 6 10 15
i: 1
t: 2 6 10 15 17;
name: {c c c d c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 3
t: 2 6 10 15
i: 2
t: 2 6 10 15 18;
name: {c c c d d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 2
t: 2 6 10
i: 3
t: 2 6 10 15
i: 3
t: 2 6 10 15 19;
name: {c c d a a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 0
t: 2 6 11 12
i: 0
t: 2 6 11 12 16;
name: {c c d a b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 0
t: 2 6 11 12
i: 1
t: 2 6 11 12 17;
name: {c c d a c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 0
t: 2 6 11 12
i: 2
t: 2 6 11 12 18;
name: {c c d a d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 0
t: 2 6 11 12
i: 3
t: 2 6 11 12 19;
name: {c c d b a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 1
t: 2 6 11 13
i: 0
t: 2 6 11 13 16;
name: {c c d b b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 1
t: 2 6 11 13
i: 1
t: 2 6 11 13 17;
name: {c c d b c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 1
t: 2 6 11 13
i: 2
t: 2 6 11 13 18;
name: {c c d b d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 1
t: 2 6 11 13
i: 3
t: 2 6 11 13 19;
name: {c c d c a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 2
t: 2 6 11 14
i: 0
t: 2 6 11 14 16;
name: {c c d c b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 2
t: 2 6 11 14
i: 1
t: 2 6 11 14 17;
name: {c c d c c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 2
t: 2 6 11 14
i: 2
t: 2 6 11 14 18;
name: {c c d c d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 2
t: 2 6 11 14
i: 3
t: 2 6 11 14 19;
name: {c c d d a} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 3
t: 2 6 11 15
i: 0
t: 2 6 11 15 16;
name: {c c d d b} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 3
t: 2 6 11 15
i: 1
t: 2 6 11 15 17;
name: {c c d d c} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 3
t: 2 6 11 15
i: 2
t: 2 6 11 15 18;
name: {c c d d d} 5
i: 2
t: 2
i: 2
t: 2 6
i: 3
t: 2 6 11
i: 3
t: 2 6 11 15
i: 3
t: 2 6 11 15 19;
name: {c d a a a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 0
t: 2 7 8 12
i: 0
t: 2 7 8 12 16;
name: {c d a a b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 0
t: 2 7 8 12
i: 1
t: 2 7 8 12 17;
name: {c d a a c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 0
t: 2 7 8 12
i: 2
t: 2 7 8 12 18;
name: {c d a a d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 0
t: 2 7 8 12
i: 3
t: 2 7 8 12 19;
name: {c d a b a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 1
t: 2 7 8 13
i: 0
t: 2 7 8 13 16;
name: {c d a b b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 1
t: 2 7 8 13
i: 1
t: 2 7 8 13 17;
name: {c d a b c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 1
t: 2 7 8 13
i: 2
t: 2 7 8 13 18;
name: {c d a b d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 1
t: 2 7 8 13
i: 3
t: 2 7 8 13 19;
name: {c d a c a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 2
t: 2 7 8 14
i: 0
t: 2 7 8 14 16;
name: {c d a c b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 2
t: 2 7 8 14
i: 1
t: 2 7 8 14 17;
name: {c d a c c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 2
t: 2 7 8 14
i: 2
t: 2 7 8 14 18;
name: {c d a c d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 2
t: 2 7 8 14
i: 3
t: 2 7 8 14 19;
name: {c d a d a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 3
t: 2 7 8 15
i: 0
t: 2 7 8 15 16;
name: {c d a d b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 3
t: 2 7 8 15
i: 1
t: 2 7 8 15 17;
name: {c d a d c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 3
t: 2 7 8 15
i: 2
t: 2 7 8 15 18;
name: {c d a d d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 0
t: 2 7 8
i: 3
t: 2 7 8 15
i: 3
t: 2 7 8 15 19;
name: {c d b a a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 0
t: 2 7 9 12
i: 0
t: 2 7 9 12 16;
name: {c d b a b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 0
t: 2 7 9 12
i: 1
t: 2 7 9 12 17;
name: {c d b a c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 0
t: 2 7 9 12
i: 2
t: 2 7 9 12 18;
name: {c d b a d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 0
t: 2 7 9 12
i: 3
t: 2 7 9 12 19;
name: {c d b b a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 1
t: 2 7 9 13
i: 0
t: 2 7 9 13 16;
name: {c d b b b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 1
t: 2 7 9 13
i: 1
t: 2 7 9 13 17;
name: {c d b b c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 1
t: 2 7 9 13
i: 2
t: 2 7 9 13 18;
name: {c d b b d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 1
t: 2 7 9 13
i: 3
t: 2 7 9 13 19;
name: {c d b c a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 2
t: 2 7 9 14
i: 0
t: 2 7 9 14 16;
name: {c d b c b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 2
t: 2 7 9 14
i: 1
t: 2 7 9 14 17;
name: {c d b c c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 2
t: 2 7 9 14
i: 2
t: 2 7 9 14 18;
name: {c d b c d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 2
t: 2 7 9 14
i: 3
t: 2 7 9 14 19;
name: {c d b d a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 3
t: 2 7 9 15
i: 0
t: 2 7 9 15 16;
name: {c d b d b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 3
t: 2 7 9 15
i: 1
t: 2 7 9 15 17;
name: {c d b d c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 3
t: 2 7 9 15
i: 2
t: 2 7 9 15 18;
name: {c d b d d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 1
t: 2 7 9
i: 3
t: 2 7 9 15
i: 3
t: 2 7 9 15 19;
name: {c d c a a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 0
t: 2 7 10 12
i: 0
t: 2 7 10 12 16;
name: {c d c a b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 0
t: 2 7 10 12
i: 1
t: 2 7 10 12 17;
name: {c d c a c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 0
t: 2 7 10 12
i: 2
t: 2 7 10 12 18;
name: {c d c a d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 0
t: 2 7 10 12
i: 3
t: 2 7 10 12 19;
name: {c d c b a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 1
t: 2 7 10 13
i: 0
t: 2 7 10 13 16;
name: {c d c b b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 1
t: 2 7 10 13
i: 1
t: 2 7 10 13 17;
name: {c d c b c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 1
t: 2 7 10 13
i: 2
t: 2 7 10 13 18;
name: {c d c b d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 1
t: 2 7 10 13
i: 3
t: 2 7 10 13 19;
name: {c d c c a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 2
t: 2 7 10 14
i: 0
t: 2 7 10 14 16;
name: {c d c c b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 2
t: 2 7 10 14
i: 1
t: 2 7 10 14 17;
name: {c d c c c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 2
t: 2 7 10 14
i: 2
t: 2 7 10 14 18;
name: {c d c c d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 2
t: 2 7 10 14
i: 3
t: 2 7 10 14 19;
name: {c d c d a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 3
t: 2 7 10 15
i: 0
t: 2 7 10 15 16;
name: {c d c d b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 3
t: 2 7 10 15
i: 1
t: 2 7 10 15 17;
name: {c d c d c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 3
t: 2 7 10 15
i: 2
t: 2 7 10 15 18;
name: {c d c d d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 2
t: 2 7 10
i: 3
t: 2 7 10 15
i: 3
t: 2 7 10 15 19;
name: {c d d a a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 0
t: 2 7 11 12
i: 0
t: 2 7 11 12 16;
name: {c d d a b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 0
t: 2 7 11 12
i: 1
t: 2 7 11 12 17;
name: {c d d a c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 0
t: 2 7 11 12
i: 2
t: 2 7 11 12 18;
name: {c d d a d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 0
t: 2 7 11 12
i: 3
t: 2 7 11 12 19;
name: {c d d b a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 1
t: 2 7 11 13
i: 0
t: 2 7 11 13 16;
name: {c d d b b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 1
t: 2 7 11 13
i: 1
t: 2 7 11 13 17;
name: {c d d b c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 1
t: 2 7 11 13
i: 2
t: 2 7 11 13 18;
name: {c d d b d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 1
t: 2 7 11 13
i: 3
t: 2 7 11 13 19;
name: {c d d c a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 2
t: 2 7 11 14
i: 0
t: 2 7 11 14 16;
name: {c d d c b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 2
t: 2 7 11 14
i: 1
t: 2 7 11 14 17;
name: {c d d c c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 2
t: 2 7 11 14
i: 2
t: 2 7 11 14 18;
name: {c d d c d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 2
t: 2 7 11 14
i: 3
t: 2 7 11 14 19;
name: {c d d d a} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 3
t: 2 7 11 15
i: 0
t: 2 7 11 15 16;
name: {c d d d b} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 3
t: 2 7 11 15
i: 1
t: 2 7 11 15 17;
name: {c d d d c} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 3
t: 2 7 11 15
i: 2
t: 2 7 11 15 18;
name: {c d d d d} 5
i: 2
t: 2
i: 3
t: 2 7
i: 3
t: 2 7 11
i: 3
t: 2 7 11 15
i: 3
t: 2 7 11 15 19;
name: {d a a a a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 0
t: 3 4 8 12
i: 0
t: 3 4 8 12 16;
name: {d a a a b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 0
t: 3 4 8 12
i: 1
t: 3 4 8 12 17;
name: {d a a a c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 0
t: 3 4 8 12
i: 2
t: 3 4 8 12 18;
name: {d a a a d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 0
t: 3 4 8 12
i: 3
t: 3 4 8 12 19;
name: {d a a b a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 1
t: 3 4 8 13
i: 0
t: 3 4 8 13 16;
name: {d a a b b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 1
t: 3 4 8 13
i: 1
t: 3 4 8 13 17;
name: {d a a b c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 1
t: 3 4 8 13
i: 2
t: 3 4 8 13 18;
name: {d a a b d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 1
t: 3 4 8 13
i: 3
t: 3 4 8 13 19;
name: {d a a c a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 2
t: 3 4 8 14
i: 0
t: 3 4 8 14 16;
name: {d a a c b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 2
t: 3 4 8 14
i: 1
t: 3 4 8 14 17;
name: {d a a c c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 2
t: 3 4 8 14
i: 2
t: 3 4 8 14 18;
name: {d a a c d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 2
t: 3 4 8 14
i: 3
t: 3 4 8 14 19;
name: {d a a d a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 3
t: 3 4 8 15
i: 0
t: 3 4 8 15 16;
name: {d a a d b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 3
t: 3 4 8 15
i: 1
t: 3 4 8 15 17;
name: {d a a d c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 3
t: 3 4 8 15
i: 2
t: 3 4 8 15 18;
name: {d a a d d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 0
t: 3 4 8
i: 3
t: 3 4 8 15
i: 3
t: 3 4 8 15 19;
name: {d a b a a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 0
t: 3 4 9 12
i: 0
t: 3 4 9 12 16;
name: {d a b a b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 0
t: 3 4 9 12
i: 1
t: 3 4 9 12 17;
name: {d a b a c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 0
t: 3 4 9 12
i: 2
t: 3 4 9 12 18;
name: {d a b a d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 0
t: 3 4 9 12
i: 3
t: 3 4 9 12 19;
name: {d a b b a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 1
t: 3 4 9 13
i: 0
t: 3 4 9 13 16;
name: {d a b b b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 1
t: 3 4 9 13
i: 1
t: 3 4 9 13 17;
name: {d a b b c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 1
t: 3 4 9 13
i: 2
t: 3 4 9 13 18;
name: {d a b b d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 1
t: 3 4 9 13
i: 3
t: 3 4 9 13 19;
name: {d a b c a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 2
t: 3 4 9 14
i: 0
t: 3 4 9 14 16;
name: {d a b c b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 2
t: 3 4 9 14
i: 1
t: 3 4 9 14 17;
name: {d a b c c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 2
t: 3 4 9 14
i: 2
t: 3 4 9 14 18;
name: {d a b c d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 2
t: 3 4 9 14
i: 3
t: 3 4 9 14 19;
name: {d a b d a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 3
t: 3 4 9 15
i: 0
t: 3 4 9 15 16;
name: {d a b d b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 3
t: 3 4 9 15
i: 1
t: 3 4 9 15 17;
name: {d a b d c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 3
t: 3 4 9 15
i: 2
t: 3 4 9 15 18;
name: {d a b d d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 1
t: 3 4 9
i: 3
t: 3 4 9 15
i: 3
t: 3 4 9 15 19;
name: {d a c a a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 0
t: 3 4 10 12
i: 0
t: 3 4 10 12 16;
name: {d a c a b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 0
t: 3 4 10 12
i: 1
t: 3 4 10 12 17;
name: {d a c a c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 0
t: 3 4 10 12
i: 2
t: 3 4 10 12 18;
name: {d a c a d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 0
t: 3 4 10 12
i: 3
t: 3 4 10 12 19;
name: {d a c b a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 1
t: 3 4 10 13
i: 0
t: 3 4 10 13 16;
name: {d a c b b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 1
t: 3 4 10 13
i: 1
t: 3 4 10 13 17;
name: {d a c b c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 1
t: 3 4 10 13
i: 2
t: 3 4 10 13 18;
name: {d a c b d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 1
t: 3 4 10 13
i: 3
t: 3 4 10 13 19;
name: {d a c c a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 2
t: 3 4 10 14
i: 0
t: 3 4 10 14 16;
name: {d a c c b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 2
t: 3 4 10 14
i: 1
t: 3 4 10 14 17;
name: {d a c c c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 2
t: 3 4 10 14
i: 2
t: 3 4 10 14 18;
name: {d a c c d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 2
t: 3 4 10 14
i: 3
t: 3 4 10 14 19;
name: {d a c d a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 3
t: 3 4 10 15
i: 0
t: 3 4 10 15 16;
name: {d a c d b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 3
t: 3 4 10 15
i: 1
t: 3 4 10 15 17;
name: {d a c d c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 3
t: 3 4 10 15
i: 2
t: 3 4 10 15 18;
name: {d a c d d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 2
t: 3 4 10
i: 3
t: 3 4 10 15
i: 3
t: 3 4 10 15 19;
name: {d a d a a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 0
t: 3 4 11 12
i: 0
t: 3 4 11 12 16;
name: {d a d a b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 0
t: 3 4 11 12
i: 1
t: 3 4 11 12 17;
name: {d a d a c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 0
t: 3 4 11 12
i: 2
t: 3 4 11 12 18;
name: {d a d a d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 0
t: 3 4 11 12
i: 3
t: 3 4 11 12 19;
name: {d a d b a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 1
t: 3 4 11 13
i: 0
t: 3 4 11 13 16;
name: {d a d b b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 1
t: 3 4 11 13
i: 1
t: 3 4 11 13 17;
name: {d a d b c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 1
t: 3 4 11 13
i: 2
t: 3 4 11 13 18;
name: {d a d b d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 1
t: 3 4 11 13
i: 3
t: 3 4 11 13 19;
name: {d a d c a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 2
t: 3 4 11 14
i: 0
t: 3 4 11 14 16;
name: {d a d c b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 2
t: 3 4 11 14
i: 1
t: 3 4 11 14 17;
name: {d a d c c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 2
t: 3 4 11 14
i: 2
t: 3 4 11 14 18;
name: {d a d c d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 2
t: 3 4 11 14
i: 3
t: 3 4 11 14 19;
name: {d a d d a} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 3
t: 3 4 11 15
i: 0
t: 3 4 11 15 16;
name: {d a d d b} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 3
t: 3 4 11 15
i: 1
t: 3 4 11 15 17;
name: {d a d d c} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 3
t: 3 4 11 15
i: 2
t: 3 4 11 15 18;
name: {d a d d d} 5
i: 3
t: 3
i: 0
t: 3 4
i: 3
t: 3 4 11
i: 3
t: 3 4 11 15
i: 3
t: 3 4 11 15 19;
name: {d b a a a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 0
t: 3 5 8 12
i: 0
t: 3 5 8 12 16;
name: {d b a a b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 0
t: 3 5 8 12
i: 1
t: 3 5 8 12 17;
name: {d b a a c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 0
t: 3 5 8 12
i: 2
t: 3 5 8 12 18;
name: {d b a a d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 0
t: 3 5 8 12
i: 3
t: 3 5 8 12 19;
name: {d b a b a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 1
t: 3 5 8 13
i: 0
t: 3 5 8 13 16;
name: {d b a b b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 1
t: 3 5 8 13
i: 1
t: 3 5 8 13 17;
name: {d b a b c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 1
t: 3 5 8 13
i: 2
t: 3 5 8 13 18;
name: {d b a b d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 1
t: 3 5 8 13
i: 3
t: 3 5 8 13 19;
name: {d b a c a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 2
t: 3 5 8 14
i: 0
t: 3 5 8 14 16;
name: {d b a c b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 2
t: 3 5 8 14
i: 1
t: 3 5 8 14 17;
name: {d b a c c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 2
t: 3 5 8 14
i: 2
t: 3 5 8 14 18;
name: {d b a c d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 2
t: 3 5 8 14
i: 3
t: 3 5 8 14 19;
name: {d b a d a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 3
t: 3 5 8 15
i: 0
t: 3 5 8 15 16;
name: {d b a d b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 3
t: 3 5 8 15
i: 1
t: 3 5 8 15 17;
name: {d b a d c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 3
t: 3 5 8 15
i: 2
t: 3 5 8 15 18;
name: {d b a d d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 0
t: 3 5 8
i: 3
t: 3 5 8 15
i: 3
t: 3 5 8 15 19;
name: {d b b a a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 0
t: 3 5 9 12
i: 0
t: 3 5 9 12 16;
name: {d b b a b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 0
t: 3 5 9 12
i: 1
t: 3 5 9 12 17;
name: {d b b a c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 0
t: 3 5 9 12
i: 2
t: 3 5 9 12 18;
name: {d b b a d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 0
t: 3 5 9 12
i: 3
t: 3 5 9 12 19;
name: {d b b b a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 1
t: 3 5 9 13
i: 0
t: 3 5 9 13 16;
name: {d b b b b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 1
t: 3 5 9 13
i: 1
t: 3 5 9 13 17;
name: {d b b b c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 1
t: 3 5 9 13
i: 2
t: 3 5 9 13 18;
name: {d b b b d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 1
t: 3 5 9 13
i: 3
t: 3 5 9 13 19;
name: {d b b c a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 2
t: 3 5 9 14
i: 0
t: 3 5 9 14 16;
name: {d b b c b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 2
t: 3 5 9 14
i: 1
t: 3 5 9 14 17;
name: {d b b c c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 2
t: 3 5 9 14
i: 2
t: 3 5 9 14 18;
name: {d b b c d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 2
t: 3 5 9 14
i: 3
t: 3 5 9 14 19;
name: {d b b d a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 3
t: 3 5 9 15
i: 0
t: 3 5 9 15 16;
name: {d b b d b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 3
t: 3 5 9 15
i: 1
t: 3 5 9 15 17;
name: {d b b d c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 3
t: 3 5 9 15
i: 2
t: 3 5 9 15 18;
name: {d b b d d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 1
t: 3 5 9
i: 3
t: 3 5 9 15
i: 3
t: 3 5 9 15 19;
name: {d b c a a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 0
t: 3 5 10 12
i: 0
t: 3 5 10 12 16;
name: {d b c a b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 0
t: 3 5 10 12
i: 1
t: 3 5 10 12 17;
name: {d b c a c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 0
t: 3 5 10 12
i: 2
t: 3 5 10 12 18;
name: {d b c a d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 0
t: 3 5 10 12
i: 3
t: 3 5 10 12 19;
name: {d b c b a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 1
t: 3 5 10 13
i: 0
t: 3 5 10 13 16;
name: {d b c b b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 1
t: 3 5 10 13
i: 1
t: 3 5 10 13 17;
name: {d b c b c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 1
t: 3 5 10 13
i: 2
t: 3 5 10 13 18;
name: {d b c b d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 1
t: 3 5 10 13
i: 3
t: 3 5 10 13 19;
name: {d b c c a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 2
t: 3 5 10 14
i: 0
t: 3 5 10 14 16;
name: {d b c c b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 2
t: 3 5 10 14
i: 1
t: 3 5 10 14 17;
name: {d b c c c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 2
t: 3 5 10 14
i: 2
t: 3 5 10 14 18;
name: {d b c c d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 2
t: 3 5 10 14
i: 3
t: 3 5 10 14 19;
name: {d b c d a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 3
t: 3 5 10 15
i: 0
t: 3 5 10 15 16;
name: {d b c d b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 3
t: 3 5 10 15
i: 1
t: 3 5 10 15 17;
name: {d b c d c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 3
t: 3 5 10 15
i: 2
t: 3 5 10 15 18;
name: {d b c d d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 2
t: 3 5 10
i: 3
t: 3 5 10 15
i: 3
t: 3 5 10 15 19;
name: {d b d a a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 0
t: 3 5 11 12
i: 0
t: 3 5 11 12 16;
name: {d b d a b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 0
t: 3 5 11 12
i: 1
t: 3 5 11 12 17;
name: {d b d a c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 0
t: 3 5 11 12
i: 2
t: 3 5 11 12 18;
name: {d b d a d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 0
t: 3 5 11 12
i: 3
t: 3 5 11 12 19;
name: {d b d b a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 1
t: 3 5 11 13
i: 0
t: 3 5 11 13 16;
name: {d b d b b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 1
t: 3 5 11 13
i: 1
t: 3 5 11 13 17;
name: {d b d b c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 1
t: 3 5 11 13
i: 2
t: 3 5 11 13 18;
name: {d b d b d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 1
t: 3 5 11 13
i: 3
t: 3 5 11 13 19;
name: {d b d c a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 2
t: 3 5 11 14
i: 0
t: 3 5 11 14 16;
name: {d b d c b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 2
t: 3 5 11 14
i: 1
t: 3 5 11 14 17;
name: {d b d c c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 2
t: 3 5 11 14
i: 2
t: 3 5 11 14 18;
name: {d b d c d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 2
t: 3 5 11 14
i: 3
t: 3 5 11 14 19;
name: {d b d d a} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 3
t: 3 5 11 15
i: 0
t: 3 5 11 15 16;
name: {d b d d b} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 3
t: 3 5 11 15
i: 1
t: 3 5 11 15 17;
name: {d b d d c} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 3
t: 3 5 11 15
i: 2
t: 3 5 11 15 18;
name: {d b d d d} 5
i: 3
t: 3
i: 1
t: 3 5
i: 3
t: 3 5 11
i: 3
t: 3 5 11 15
i: 3
t: 3 5 11 15 19;
name: {d c a a a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 0
t: 3 6 8 12
i: 0
t: 3 6 8 12 16;
name: {d c a a b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 0
t: 3 6 8 12
i: 1
t: 3 6 8 12 17;
name: {d c a a c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 0
t: 3 6 8 12
i: 2
t: 3 6 8 12 18;
name: {d c a a d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 0
t: 3 6 8 12
i: 3
t: 3 6 8 12 19;
name: {d c a b a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 1
t: 3 6 8 13
i: 0
t: 3 6 8 13 16;
name: {d c a b b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 1
t: 3 6 8 13
i: 1
t: 3 6 8 13 17;
name: {d c a b c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 1
t: 3 6 8 13
i: 2
t: 3 6 8 13 18;
name: {d c a b d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 1
t: 3 6 8 13
i: 3
t: 3 6 8 13 19;
name: {d c a c a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 2
t: 3 6 8 14
i: 0
t: 3 6 8 14 16;
name: {d c a c b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 2
t: 3 6 8 14
i: 1
t: 3 6 8 14 17;
name: {d c a c c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 2
t: 3 6 8 14
i: 2
t: 3 6 8 14 18;
name: {d c a c d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 2
t: 3 6 8 14
i: 3
t: 3 6 8 14 19;
name: {d c a d a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 3
t: 3 6 8 15
i: 0
t: 3 6 8 15 16;
name: {d c a d b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 3
t: 3 6 8 15
i: 1
t: 3 6 8 15 17;
name: {d c a d c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 3
t: 3 6 8 15
i: 2
t: 3 6 8 15 18;
name: {d c a d d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 0
t: 3 6 8
i: 3
t: 3 6 8 15
i: 3
t: 3 6 8 15 19;
name: {d c b a a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 0
t: 3 6 9 12
i: 0
t: 3 6 9 12 16;
name: {d c b a b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 0
t: 3 6 9 12
i: 1
t: 3 6 9 12 17;
name: {d c b a c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 0
t: 3 6 9 12
i: 2
t: 3 6 9 12 18;
name: {d c b a d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 0
t: 3 6 9 12
i: 3
t: 3 6 9 12 19;
name: {d c b b a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 1
t: 3 6 9 13
i: 0
t: 3 6 9 13 16;
name: {d c b b b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 1
t: 3 6 9 13
i: 1
t: 3 6 9 13 17;
name: {d c b b c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 1
t: 3 6 9 13
i: 2
t: 3 6 9 13 18;
name: {d c b b d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 1
t: 3 6 9 13
i: 3
t: 3 6 9 13 19;
name: {d c b c a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 2
t: 3 6 9 14
i: 0
t: 3 6 9 14 16;
name: {d c b c b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 2
t: 3 6 9 14
i: 1
t: 3 6 9 14 17;
name: {d c b c c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 2
t: 3 6 9 14
i: 2
t: 3 6 9 14 18;
name: {d c b c d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 2
t: 3 6 9 14
i: 3
t: 3 6 9 14 19;
name: {d c b d a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 3
t: 3 6 9 15
i: 0
t: 3 6 9 15 16;
name: {d c b d b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 3
t: 3 6 9 15
i: 1
t: 3 6 9 15 17;
name: {d c b d c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 3
t: 3 6 9 15
i: 2
t: 3 6 9 15 18;
name: {d c b d d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 1
t: 3 6 9
i: 3
t: 3 6 9 15
i: 3
t: 3 6 9 15 19;
name: {d c c a a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 0
t: 3 6 10 12
i: 0
t: 3 6 10 12 16;
name: {d c c a b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 0
t: 3 6 10 12
i: 1
t: 3 6 10 12 17;
name: {d c c a c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 0
t: 3 6 10 12
i: 2
t: 3 6 10 12 18;
name: {d c c a d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 0
t: 3 6 10 12
i: 3
t: 3 6 10 12 19;
name: {d c c b a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 1
t: 3 6 10 13
i: 0
t: 3 6 10 13 16;
name: {d c c b b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 1
t: 3 6 10 13
i: 1
t: 3 6 10 13 17;
name: {d c c b c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 1
t: 3 6 10 13
i: 2
t: 3 6 10 13 18;
name: {d c c b d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 1
t: 3 6 10 13
i: 3
t: 3 6 10 13 19;
name: {d c c c a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 2
t: 3 6 10 14
i: 0
t: 3 6 10 14 16;
name: {d c c c b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 2
t: 3 6 10 14
i: 1
t: 3 6 10 14 17;
name: {d c c c c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 2
t: 3 6 10 14
i: 2
t: 3 6 10 14 18;
name: {d c c c d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 2
t: 3 6 10 14
i: 3
t: 3 6 10 14 19;
name: {d c c d a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 3
t: 3 6 10 15
i: 0
t: 3 6 10 15 16;
name: {d c c d b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 3
t: 3 6 10 15
i: 1
t: 3 6 10 15 17;
name: {d c c d c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 3
t: 3 6 10 15
i: 2
t: 3 6 10 15 18;
name: {d c c d d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 2
t: 3 6 10
i: 3
t: 3 6 10 15
i: 3
t: 3 6 10 15 19;
name: {d c d a a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 0
t: 3 6 11 12
i: 0
t: 3 6 11 12 16;
name: {d c d a b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 0
t: 3 6 11 12
i: 1
t: 3 6 11 12 17;
name: {d c d a c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 0
t: 3 6 11 12
i: 2
t: 3 6 11 12 18;
name: {d c d a d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 0
t: 3 6 11 12
i: 3
t: 3 6 11 12 19;
name: {d c d b a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 1
t: 3 6 11 13
i: 0
t: 3 6 11 13 16;
name: {d c d b b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 1
t: 3 6 11 13
i: 1
t: 3 6 11 13 17;
name: {d c d b c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 1
t: 3 6 11 13
i: 2
t: 3 6 11 13 18;
name: {d c d b d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 1
t: 3 6 11 13
i: 3
t: 3 6 11 13 19;
name: {d c d c a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 2
t: 3 6 11 14
i: 0
t: 3 6 11 14 16;
name: {d c d c b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 2
t: 3 6 11 14
i: 1
t: 3 6 11 14 17;
name: {d c d c c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 2
t: 3 6 11 14
i: 2
t: 3 6 11 14 18;
name: {d c d c d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 2
t: 3 6 11 14
i: 3
t: 3 6 11 14 19;
name: {d c d d a} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 3
t: 3 6 11 15
i: 0
t: 3 6 11 15 16;
name: {d c d d b} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 3
t: 3 6 11 15
i: 1
t: 3 6 11 15 17;
name: {d c d d c} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 3
t: 3 6 11 15
i: 2
t: 3 6 11 15 18;
name: {d c d d d} 5
i: 3
t: 3
i: 2
t: 3 6
i: 3
t: 3 6 11
i: 3
t: 3 6 11 15
i: 3
t: 3 6 11 15 19;
name: {d d a a a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 0
t: 3 7 8 12
i: 0
t: 3 7 8 12 16;
name: {d d a a b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 0
t: 3 7 8 12
i: 1
t: 3 7 8 12 17;
name: {d d a a c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 0
t: 3 7 8 12
i: 2
t: 3 7 8 12 18;
name: {d d a a d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 0
t: 3 7 8 12
i: 3
t: 3 7 8 12 19;
name: {d d a b a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 1
t: 3 7 8 13
i: 0
t: 3 7 8 13 16;
name: {d d a b b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 1
t: 3 7 8 13
i: 1
t: 3 7 8 13 17;
name: {d d a b c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 1
t: 3 7 8 13
i: 2
t: 3 7 8 13 18;
name: {d d a b d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 1
t: 3 7 8 13
i: 3
t: 3 7 8 13 19;
name: {d d a c a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 2
t: 3 7 8 14
i: 0
t: 3 7 8 14 16;
name: {d d a c b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 2
t: 3 7 8 14
i: 1
t: 3 7 8 14 17;
name: {d d a c c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 2
t: 3 7 8 14
i: 2
t: 3 7 8 14 18;
name: {d d a c d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 2
t: 3 7 8 14
i: 3
t: 3 7 8 14 19;
name: {d d a d a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 3
t: 3 7 8 15
i: 0
t: 3 7 8 15 16;
name: {d d a d b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 3
t: 3 7 8 15
i: 1
t: 3 7 8 15 17;
name: {d d a d c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 3
t: 3 7 8 15
i: 2
t: 3 7 8 15 18;
name: {d d a d d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 0
t: 3 7 8
i: 3
t: 3 7 8 15
i: 3
t: 3 7 8 15 19;
name: {d d b a a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 0
t: 3 7 9 12
i: 0
t: 3 7 9 12 16;
name: {d d b a b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 0
t: 3 7 9 12
i: 1
t: 3 7 9 12 17;
name: {d d b a c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 0
t: 3 7 9 12
i: 2
t: 3 7 9 12 18;
name: {d d b a d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 0
t: 3 7 9 12
i: 3
t: 3 7 9 12 19;
name: {d d b b a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 1
t: 3 7 9 13
i: 0
t: 3 7 9 13 16;
name: {d d b b b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 1
t: 3 7 9 13
i: 1
t: 3 7 9 13 17;
name: {d d b b c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 1
t: 3 7 9 13
i: 2
t: 3 7 9 13 18;
name: {d d b b d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 1
t: 3 7 9 13
i: 3
t: 3 7 9 13 19;
name: {d d b c a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 2
t: 3 7 9 14
i: 0
t: 3 7 9 14 16;
name: {d d b c b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 2
t: 3 7 9 14
i: 1
t: 3 7 9 14 17;
name: {d d b c c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 2
t: 3 7 9 14
i: 2
t: 3 7 9 14 18;
name: {d d b c d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 2
t: 3 7 9 14
i: 3
t: 3 7 9 14 19;
name: {d d b d a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 3
t: 3 7 9 15
i: 0
t: 3 7 9 15 16;
name: {d d b d b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 3
t: 3 7 9 15
i: 1
t: 3 7 9 15 17;
name: {d d b d c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 3
t: 3 7 9 15
i: 2
t: 3 7 9 15 18;
name: {d d b d d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 1
t: 3 7 9
i: 3
t: 3 7 9 15
i: 3
t: 3 7 9 15 19;
name: {d d c a a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 0
t: 3 7 10 12
i: 0
t: 3 7 10 12 16;
name: {d d c a b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 0
t: 3 7 10 12
i: 1
t: 3 7 10 12 17;
name: {d d c a c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 0
t: 3 7 10 12
i: 2
t: 3 7 10 12 18;
name: {d d c a d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 0
t: 3 7 10 12
i: 3
t: 3 7 10 12 19;
name: {d d c b a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 1
t: 3 7 10 13
i: 0
t: 3 7 10 13 16;
name: {d d c b b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 1
t: 3 7 10 13
i: 1
t: 3 7 10 13 17;
name: {d d c b c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 1
t: 3 7 10 13
i: 2
t: 3 7 10 13 18;
name: {d d c b d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 1
t: 3 7 10 13
i: 3
t: 3 7 10 13 19;
name: {d d c c a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 2
t: 3 7 10 14
i: 0
t: 3 7 10 14 16;
name: {d d c c b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 2
t: 3 7 10 14
i: 1
t: 3 7 10 14 17;
name: {d d c c c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 2
t: 3 7 10 14
i: 2
t: 3 7 10 14 18;
name: {d d c c d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 2
t: 3 7 10 14
i: 3
t: 3 7 10 14 19;
name: {d d c d a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 3
t: 3 7 10 15
i: 0
t: 3 7 10 15 16;
name: {d d c d b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 3
t: 3 7 10 15
i: 1
t: 3 7 10 15 17;
name: {d d c d c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 3
t: 3 7 10 15
i: 2
t: 3 7 10 15 18;
name: {d d c d d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 2
t: 3 7 10
i: 3
t: 3 7 10 15
i: 3
t: 3 7 10 15 19;
name: {d d d a a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 0
t: 3 7 11 12
i: 0
t: 3 7 11 12 16;
name: {d d d a b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 0
t: 3 7 11 12
i: 1
t: 3 7 11 12 17;
name: {d d d a c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 0
t: 3 7 11 12
i: 2
t: 3 7 11 12 18;
name: {d d d a d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 0
t: 3 7 11 12
i: 3
t: 3 7 11 12 19;
name: {d d d b a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 1
t: 3 7 11 13
i: 0
t: 3 7 11 13 16;
name: {d d d b b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 1
t: 3 7 11 13
i: 1
t: 3 7 11 13 17;
name: {d d d b c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 1
t: 3 7 11 13
i: 2
t: 3 7 11 13 18;
name: {d d d b d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 1
t: 3 7 11 13
i: 3
t: 3 7 11 13 19;
name: {d d d c a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 2
t: 3 7 11 14
i: 0
t: 3 7 11 14 16;
name: {d d d c b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 2
t: 3 7 11 14
i: 1
t: 3 7 11 14 17;
name: {d d d c c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 2
t: 3 7 11 14
i: 2
t: 3 7 11 14 18;
name: {d d d c d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 2
t: 3 7 11 14
i: 3
t: 3 7 11 14 19;
name: {d d d d a} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 3
t: 3 7 11 15
i: 0
t: 3 7 11 15 16;
name: {d d d d b} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 3
t: 3 7 11 15
i: 1
t: 3 7 11 15 17;
name: {d d d d c} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 3
t: 3 7 11 15
i: 2
t: 3 7 11 15 18;
name: {d d d d d} 5
i: 3
t: 3
i: 3
t: 3 7
i: 3
t: 3 7 11
i: 3
t: 3 7 11 15
i: 3
t: 3 7 11 15 19;
