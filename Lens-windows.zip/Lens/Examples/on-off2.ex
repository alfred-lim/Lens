min:0.5;
name:{A on}
2 b:0 t:0;
name:{B on}
2 b:1 t:1;
name:{C on}
2 b:2 t:2;
name:{D on}
2 b:3 t:3;
name:{E on}
2 b:4 t:4;
name:{F on}
2 b:5 t:5;
