name:{A D 1 2 2 1}
6
i:0 t:{-} *
i:3 t:{-} *
i: t:0
i: t:1
i: t:1
i: t:0
;
name:{B E 2 3 1 3}
6
i:1 t:{-} *
i:4 t:{-} *
i: t:1
i: t:2
i: t:0
i: t:2
;
name:{C A 3 1 1 2}
6
i:2 t:{-} *
i:0 t:{-} *
i: t:2
i: t:0
i: t:0
i: t:1
;
name:{D B 2 1 2 3}
6
i:3 t:{-} *
i:1 t:{-} *
i: t:1
i: t:0
i: t:1
i: t:2
;
name:{E C 1 3 3 1}
6
i:4 t:{-} *
i:2 t:{-} *
i: t:0
i: t:2
i: t:2
i: t:0
;
