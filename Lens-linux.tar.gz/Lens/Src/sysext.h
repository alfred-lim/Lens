/* Any customizations you want to make to system.h should be placed in here */

#ifndef SYSEXT_H
#define SYSEXT_H

/*
#ifdef MACHINE_YOURMACHINE
  include headers or define macros as necessary
#endif
*/

#endif /* SYSEXT_H */
